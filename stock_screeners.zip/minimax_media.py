#!/usr/bin/env python3
"""
MiniMax Media Generator — 圖片 + 影片 + 音樂
直接 call MiniMax API，走老大 Pay as You Go 的 $5

用法：
  # 設定 API Key（第一次）
  python minimax_media.py --set-key "你的APIKey"

  # 圖片生成
  python minimax_media.py image "一隻可愛的貓咪"
  python minimax_media.py image "夕陽下的沙灘" --ar 16:9 --n 4

  # 影片生成
  python minimax_media.py video "一個人在海邊跑步"
  python minimax_media.py video "機器人在跳舞" --duration 10 --resolution 1080P

  # 音樂生成
  python minimax_media.py music "輕快的鋼琴曲"
  python minimax_media.py music "熱血搖滾" "燃燒吧！我的小宇宙"

取得 API Key → https://platform.minimax.io
"""

import json, ssl, urllib.request, os, sys, time, base64
from datetime import datetime

CONFIG_PATH = os.path.expanduser("~/.openclaw/credentials/minimax.json")
API_BASE = "https://api.minimax.io"


# ── 價格表 ──
PRICES = {
    "image": {"model": "image-01", "price": 0.0035, "unit": "張"},
    "video_768_6s": {"model": "MiniMax-Hailuo-2.3", "price": 0.28, "unit": "部"},
    "video_768_10s": {"model": "MiniMax-Hailuo-2.3", "price": 0.56, "unit": "部"},
    "video_1080_6s": {"model": "MiniMax-Hailuo-2.3", "price": 0.49, "unit": "部"},
    "video_1080_10s": {"model": "MiniMax-Hailuo-2.3-Fast", "price": 0.33, "unit": "部"},
    "music": {"model": "music-01", "price": 0.15, "unit": "首"},
}


def load_key():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f).get("api_key", "")
        except: pass
    return ""


def save_key(api_key):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump({"api_key": api_key}, f, indent=2)
    os.chmod(CONFIG_PATH, 0o600)
    print("  API Key 已儲存")


def call_api(endpoint, payload, timeout=120):
    """call MiniMax API"""
    api_key = load_key()
    if not api_key:
        print("  請先設定 API Key: python minimax_media.py --set-key '你的Key'")
        return None

    ctx = ssl.create_default_context()
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "xiaohu-media/1.0",
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  HTTP {e.code}: {body[:300]}")
        return None
    except Exception as e:
        print(f"  錯誤: {e}")
        return None


def query_task(endpoint, timeout=30):
    """查詢非同步任務狀態"""
    api_key = load_key()
    if not api_key:
        return None
    ctx = ssl.create_default_context()
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "xiaohu-media/1.0",
    }
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except Exception as e:
        print(f"  查詢錯誤: {e}")
        return None


def wait_task(task_id, query_endpoint, max_wait=300, interval=10):
    """等待非同步任務完成"""
    print(f"  等待任務完成...", end="", flush=True)
    for _ in range(max_wait // interval):
        time.sleep(interval)
        result = query_task(f"{query_endpoint}/{task_id}")
        if result:
            status = result.get("status", "")
            print(".", end="", flush=True)
            if status == "Success" or status == "success":
                print(" ✅")
                return result
            elif status in ("Failed", "fail", "error"):
                print(" ❌")
                print(f"  失敗: {result.get('message', '')}")
                return None
        else:
            print("?", end="", flush=True)
    print(" ⏰ 逾時")
    return None


# ═══════════════════════════════════
#  圖片
# ═══════════════════════════════════
def generate_image(prompt, aspect_ratio="1:1", n=1):
    """生成圖片"""
    print(f"\n🖼️  生成圖片...")
    print(f"   提示詞: {prompt}")
    print(f"   比例: {aspect_ratio} | 張數: {n}")
    total = PRICES["image"]["price"] * n
    print(f"   費用: ${total:.4f} (剩 ${5 - total:.4f})")

    payload = {
        "model": "image-01",
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "n": min(n, 9),
        "response_format": "url",
        "prompt_optimizer": True,
    }
    result = call_api("/v1/image_generation", payload, timeout=60)
    if not result:
        return None

    images = []
    data = result.get("data", [])
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                url = item.get("url", "")
                if url:
                    images.append(url)
                    print(f"  🔗 {url}")
    if not images and result.get("image_url"):
        images.append(result["image_url"])
        print(f"  🔗 {result['image_url']}")

    print(f"  ✅ {len(images)} 張圖片")
    return images


# ═══════════════════════════════════
#  影片（非同步任務）
# ═══════════════════════════════════
def generate_video(prompt, duration=6, resolution="768P"):
    """生成影片"""
    print(f"\n🎬  生成影片...")
    print(f"   提示詞: {prompt}")
    print(f"   時長: {duration}秒 | 解析度: {resolution}")

    key = f"video_{resolution.lower()}_{duration}s"
    if key in PRICES:
        print(f"   費用: ${PRICES[key]['price']:.2f} (剩 ${5 - PRICES[key]['price']:.2f})")
    else:
        print(f"   費用: 約 $0.28~$0.56")

    model = "MiniMax-Hailuo-2.3-Fast" if resolution == "1080P" else "MiniMax-Hailuo-2.3"
    payload = {
        "model": model,
        "prompt": prompt,
        "duration": min(duration, 10),
        "resolution": resolution,
    }
    result = call_api("/v1/video_generation", payload, timeout=30)
    if not result:
        return None

    task_id = result.get("task_id")
    if task_id:
        print(f"   任務ID: {task_id}")
        final = wait_task(task_id, "/v1/video_generation/result", max_wait=300)
        if final:
            videos = final.get("data", [])
            if isinstance(videos, list):
                for v in videos:
                    if isinstance(v, dict):
                        url = v.get("url", "")
                        if url:
                            print(f"  🔗 {url}")
                            return url
            print(f"   結果: {json.dumps(final, indent=2, ensure_ascii=False)[:500]}")
            return final
    else:
        # 同步結果
        videos = result.get("data", [])
        for v in videos:
            if isinstance(v, dict):
                url = v.get("url", "")
                if url:
                    print(f"  🔗 {url}")
                    return url
        print(f"   結果: {json.dumps(result, indent=2, ensure_ascii=False)[:300]}")
        return result


# ═══════════════════════════════════
#  音樂（非同步任務）
# ═══════════════════════════════════
def generate_music(prompt, lyrics=None):
    """生成音樂"""
    print(f"\n🎵  生成音樂...")
    print(f"   提示詞: {prompt}")
    if lyrics: print(f"   歌詞: {lyrics[:60]}...")
    print(f"   費用: $0.15 (剩 ${5 - 0.15:.2f})")

    payload = {
        "model": "music-01",
        "prompt": prompt,
    }
    if lyrics:
        payload["lyrics"] = lyrics
        payload["lyrics_type"] = "user"

    result = call_api("/v1/music/generate", payload, timeout=180)
    if not result:
        return None

    # 音樂可能是非同步
    task_id = result.get("task_id")
    if task_id:
        print(f"   任務ID: {task_id}")
        final = wait_task(task_id, "/v1/music/result", max_wait=300, interval=15)
        if final:
            audio_url = final.get("audio_url") or final.get("url", "")
            if audio_url:
                print(f"  🔗 {audio_url}")
                return audio_url
            print(f"   結果: {json.dumps(final, indent=2, ensure_ascii=False)[:500]}")
            return final
    else:
        audio_url = result.get("audio_url") or result.get("url", "")
        if audio_url:
            print(f"  🔗 {audio_url}")
            return audio_url
        print(f"   結果: {json.dumps(result, indent=2, ensure_ascii=False)[:500]}")
        return result


# ═══════════════════════════════════
#  主程式
# ═══════════════════════════════════
def usage():
    print("=" * 55)
    print(" MiniMax Media Generator — 用 $5 生圖/影片/音樂")
    print("=" * 55)
    print()
    print(" 設定:")
    print("  python minimax_media.py --set-key \"你的Key\"")
    print()
    print(" 圖片 (image-01 = $0.0035/張):")
    print('  python minimax_media.py image "一隻可愛的貓咪"')
    print('  python minimax_media.py image "夕陽" --ar 16:9 --n 4')
    print()
    print(" 影片 (Hailuo-2.3 = $0.28~$0.56/部):")
    print('  python minimax_media.py video "機器人跳舞"')
    print('  python minimax_media.py video "海邊跑步" --duration 10 --resolution 1080P')
    print()
    print(" 音樂 (music-01 = $0.15/首):")
    print('  python minimax_media.py music "輕快的鋼琴曲"')
    print('  python minimax_media.py music "熱血搖滾" "燃燒吧！我的小宇宙"')
    print()
    print(f" $5 可以生:")
    print(f"   • 圖片: {int(5/0.0035)} 張")
    print(f"   • 影片 768P: {int(5/0.28)} 部")
    print(f"   • 影片 1080P: {int(5/0.49)} 部")
    print(f"   • 音樂: {int(5/0.15)} 首")


def main():
    if len(sys.argv) < 2:
        usage()
        return

    cmd = sys.argv[1]

    if cmd == "--set-key" and len(sys.argv) > 2:
        save_key(sys.argv[2])
        return

    if cmd == "image" and len(sys.argv) >= 3:
        prompt = sys.argv[2]
        aspect_ratio = "1:1"
        n = 1
        args = sys.argv[3:]
        for i, a in enumerate(args):
            if a == "--ar" and i + 1 < len(args):
                aspect_ratio = args[i + 1]
            if a == "--n" and i + 1 < len(args):
                try: n = int(args[i + 1])
                except: pass
        generate_image(prompt, aspect_ratio, n)
        return

    if cmd == "video" and len(sys.argv) >= 3:
        prompt = sys.argv[2]
        duration = 6
        resolution = "768P"
        args = sys.argv[3:]
        for i, a in enumerate(args):
            if a == "--duration" and i + 1 < len(args):
                try: duration = int(args[i + 1])
                except: pass
            if a == "--resolution" and i + 1 < len(args):
                resolution = args[i + 1]
        generate_video(prompt, duration, resolution)
        return

    if cmd == "music" and len(sys.argv) >= 3:
        prompt = sys.argv[2]
        lyrics = sys.argv[3] if len(sys.argv) > 3 else None
        generate_music(prompt, lyrics)
        return

    usage()


if __name__ == "__main__":
    main()
