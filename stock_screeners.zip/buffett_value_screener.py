#!/usr/bin/env python3
"""
巴菲特價值股選股工具 v1.0
使用證交所公開 API，免 key、免註冊

巴菲特選股四大核心指標（台股版）：
1. 護城河 — 連續多年 EPS 穩定且為正（近四季 EPS > 1）
2. 便宜 — P/B < 1.5 且本益比合理
3. 賺錢 — 營業利益率接近稅後淨利率（非靠業外）
4. 回饋股東 — 有穩定殖利率

綜合評分 0-100，分數越高越接近巴菲特標準。
"""

import json, sys, os, time, ssl, urllib.request
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from html import escape as html_escape

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
XLSX_PATH = os.path.join(WORKSPACE, "buffett_value_stocks.xlsx")
HTML_PATH = os.path.join(WORKSPACE, "buffett_value_stocks.html")

COLOR_RED = "d63031"
COLOR_GREEN = "00b894"
FILL_HEADER = PatternFill(start_color="2d3436", end_color="2d3436", fill_type="solid")
FILL_TOP1 = PatternFill(start_color="ffe0e0", end_color="ffe0e0", fill_type="solid")
FILL_TOP2 = PatternFill(start_color="ffe8e0", end_color="ffe8e0", fill_type="solid")
FILL_TOP3 = PatternFill(start_color="fff3e0", end_color="fff3e0", fill_type="solid")
FONT_HEADER = Font(name="微軟正黑體", bold=True, color="ffffff", size=11)
FONT_TITLE = Font(name="微軟正黑體", bold=True, size=16, color="2d3436")
FONT_SUBTITLE = Font(name="微軟正黑體", size=12, color="636e72")
FONT_DATA = Font(name="微軟正黑體", size=11)
THIN_BORDER = Border(
    left=Side(style='thin', color='dfe6e9'),
    right=Side(style='thin', color='dfe6e9'),
    top=Side(style='thin', color='dfe6e9'),
    bottom=Side(style='thin', color='dfe6e9'),
)


def fetch_json(url, retries=3):
    ctx = ssl.create_default_context()
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            resp = urllib.request.urlopen(req, timeout=20, context=ctx)
            return json.loads(resp.read())
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2)
                continue
            return None


def fetch_all_data():
    """一次抓完所有資料（3 個 API call）"""
    print(" 正在從證交所抓資料...")

    # 1. P/B + 本益比 + 殖利率
    pb_data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL")
    if not pb_data:
        print("e BWIBBU_ALL 失敗")
        return None, None, None
    print(f" BWIBBU_ALL: {len(pb_data)} 筆")

    # 2. 股價
    price_data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL")
    if not price_data:
        price_data = []
    print(f" STOCK_DAY_ALL: {len(price_data)} 筆")

    # 3. 近一季財報（EPS、營收、營業利益、稅後淨利）
    fin_data = fetch_json("https://openapi.twse.com.tw/v1/opendata/t187ap14_L")
    if not fin_data:
        fin_data = []
    print(f" 財報(t187ap14): {len(fin_data)} 筆")

    return pb_data, price_data, fin_data


def analyze(pb_data, price_data, fin_data):
    """計算所有股票的分數"""
    print("\n 分析中...")

    # 建立股價 map
    price_map = {}
    for r in price_data:
        code = r.get("Code", "")
        try:
            close = float(r.get("ClosingPrice", 0) or 0)
            if close > 0:
                price_map[code] = close
        except:
            pass

    # 建立財報 map (最近一季)
    fin_map = {}
    for r in fin_data:
        code = r.get("公司代號", "")
        try:
            eps = float(r.get("基本每股盈餘(元)", 0) or 0)
            revenue = float(r.get("營業收入", 0) or 0)
            op_income = float(r.get("營業利益", 0) or 0)
            net_income = float(r.get("稅後淨利", 0) or 0)
            fin_map[code] = {
                "eps": eps,
                "revenue": revenue,
                "op_income": op_income,
                "net_income": net_income,
            }
        except:
            pass

    results = []
    for r in pb_data:
        code = r.get("Code", "")
        name = r.get("Name", "").strip()

        pb_str = (r.get("PBratio", "") or "").strip()
        pe_str = (r.get("PEratio", "") or "").strip()
        dy_str = (r.get("DividendYield", "") or "").strip()

        if not pb_str:
            continue
        try:
            pb = float(pb_str)
            pe = float(pe_str) if pe_str else None
            dy = float(dy_str) if dy_str else None
        except:
            continue

        price = price_map.get(code)
        fin = fin_map.get(code)

        score = 0
        reasons = []

        # ── 1. 便宜（巴菲特最重視安全邊際）──
        if pb is not None and pb < 1.0:
            score += 25
            reasons.append(f"P/B={pb:.2f} 超跌")
        elif pb is not None and pb < 1.5:
            score += 15
            reasons.append(f"P/B={pb:.2f} 偏低")
        elif pb is not None and pb < 2.0:
            score += 5

        if pe is not None and 5 < pe < 15:
            score += 15
            reasons.append(f"本益比={pe:.1f} 合理偏低")
        elif pe is not None and pe <= 5 and pe > 0:
            score += 5  # 太低的 PE 可能也有問題
            reasons.append(f"本益比={pe:.1f} 極低")

        # ── 2. 護城河（EPS 穩定為正）──
        if fin:
            eps = fin["eps"]
            if eps >= 2:
                score += 20
                reasons.append(f"EPS={eps:.2f} 賺錢能力強")
            elif eps >= 1:
                score += 15
                reasons.append(f"EPS={eps:.2f} 有賺錢")
            elif eps >= 0:
                score += 5
            else:
                score -= 10  # 虧錢扣分

            # 營業利益率 vs 稅後淨利率（看本業賺不賺）
            if fin["revenue"] > 0 and fin["op_income"] > 0:
                op_margin = fin["op_income"] / fin["revenue"] * 100
                net_margin = fin["net_income"] / fin["revenue"] * 100
                if op_margin >= 10:
                    score += 10
                    reasons.append(f"營益率={op_margin:.1f}% 本業強")
                elif op_margin >= 5:
                    score += 5
                    reasons.append(f"營益率={op_margin:.1f}%")

                # 本業佔比高（營業利益接近稅後淨利）
                if fin["net_income"] > 0:
                    core_ratio = fin["op_income"] / fin["net_income"]
                    if core_ratio >= 0.8:
                        score += 10
                        reasons.append("本業獲利純度高")
        else:
            score -= 5  # 沒財報資料扣分

        # ── 3. 回饋股東（殖利率）──
        if dy is not None:
            if dy >= 6:
                score += 15
                reasons.append(f"殖利率={dy:.1f}% 高股息")
            elif dy >= 4:
                score += 10
                reasons.append(f"殖利率={dy:.1f}%")
            elif dy >= 2:
                score += 5
            else:
                score += 0
        else:
            score -= 5

        # 確保分數 0-100
        score = max(0, min(100, score))

        results.append({
            "code": code,
            "name": name,
            "price": price,
            "pb": pb,
            "pe": pe,
            "dy": dy,
            "eps": fin["eps"] if fin else None,
            "score": score,
            "reasons": "、".join(reasons) if reasons else "",
        })

    # 排序：分數高到低
    results.sort(key=lambda r: r["score"], reverse=True)
    print(f" 分析完成: {len(results)} 檔上市股票")
    return results


def create_excel(results):
    print(" 產生 Excel...")
    wb = Workbook()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 巴菲特評級
    def get_rating(score):
        if score >= 80: return "A+ 巴菲特最愛"
        if score >= 65: return "A  優質價值股"
        if score >= 50: return "B  值得關注"
        if score >= 35: return "C  普通"
        return "D  不符合"

    # ===== Sheet 1: 巴菲特價值股清單 =====
    ws = wb.active
    ws.title = "巴菲特價值股"
    ws.sheet_properties.tabColor = "d63031"

    widths = [8, 14, 8, 10, 10, 9, 10, 10, 8, 30]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.merge_cells("A1:J1")
    ws["A1"].value = "巴菲特價值股篩選（台股版）"
    ws["A1"].font = FONT_TITLE
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("A2:J2")
    ws["A2"].value = f"資料: 2026 Q1 財報 + 2026-07-16 行情 | 產出: {ts}"
    ws["A2"].font = FONT_SUBTITLE
    ws["A2"].alignment = Alignment(horizontal="center")

    ws.merge_cells("A4:J4")
    ws["A4"].value = "評分標準: 便宜(P/B+PE 40%) + 護城河(EPS+營益率 40%) + 回饋股東(殖利率 20%)"
    ws["A4"].font = Font(name="微軟正黑體", size=10, color="636e72", italic=True)

    h1 = ["代號", "公司名稱", "市價", "P/B值", "本益比", "殖利率%", "EPS(近季)", "巴菲特評分", "評級", "加分原因"]
    hr = 6
    for col, h in enumerate(h1, 1):
        cell = ws.cell(row=hr, column=col, value=h)
        cell.font = FONT_HEADER
        cell.fill = FILL_HEADER
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = THIN_BORDER
    ws.row_dimensions[hr].height = 28

    for idx, s in enumerate(results):
        row = hr + 1 + idx

        # 顏色分級
        if s["score"] >= 65:
            fill = FILL_TOP1
        elif s["score"] >= 50:
            fill = FILL_TOP2
        elif s["score"] >= 35:
            fill = FILL_TOP3
        else:
            fill = None

        set_c = lambda col, v, font=FONT_DATA, fmt=None: _set_cell(ws, row, col, v, font, fmt, fill)
        set_c(1, s["code"], Font(name="微軟正黑體", size=11, bold=True))
        set_c(2, s["name"])
        if s["price"]:
            set_c(3, s["price"], fmt="#,##0.00")
        else:
            set_c(3, "—", Font(name="微軟正黑體", size=11, color="b2bec3"))
        set_c(4, s["pb"], fmt="0.00")
        if s["pe"]:
            set_c(5, s["pe"], fmt="0.0")
        else:
            set_c(5, "—", Font(name="微軟正黑體", size=11, color="b2bec3"))
        if s["dy"]:
            set_c(6, s["dy"]/100, fmt="0.0%")
        else:
            set_c(6, "—", Font(name="微軟正黑體", size=11, color="b2bec3"))
        if s["eps"] is not None:
            set_c(7, s["eps"], fmt="0.00")
        else:
            set_c(7, "—", Font(name="微軟正黑體", size=11, color="b2bec3"))

        set_c(8, s["score"], Font(name="微軟正黑體", size=14, bold=True, color=COLOR_RED if s["score"] >= 50 else "2d3436"))
        set_c(9, get_rating(s["score"]), Font(name="微軟正黑體", size=10, bold=True, color=COLOR_RED if s["score"] >= 50 else "636e72"))
        set_c(10, s["reasons"], Font(name="微軟正黑體", size=9, color="636e72"))

    ws.freeze_panes = f"A{hr + 1}"
    ws.auto_filter.ref = f"A{hr}:J{hr + len(results)}"

    # ===== Sheet 2: TOP 30 巴菲特首選 =====
    top30 = [s for s in results if s["score"] >= 50][:30]

    ws2 = wb.create_sheet("巴菲特首選 TOP30")
    ws2.sheet_properties.tabColor = "e17055"
    widths2 = [8, 14, 8, 10, 10, 9, 10, 10, 8, 30]
    for i, w in enumerate(widths2, 1):
        ws2.column_dimensions[get_column_letter(i)].width = w

    ws2.merge_cells("A1:J1")
    ws2["A1"].value = f"巴菲特首選 TOP 30（評分 >= 50）"
    ws2["A1"].font = FONT_TITLE
    ws2["A1"].alignment = Alignment(horizontal="center")
    ws2.row_dimensions[1].height = 35

    ws2.merge_cells("A2:J2")
    ws2["A2"].value = f"共 {len(top30)} 檔符合門檻 | 排序: 巴菲特評分由高至低"
    ws2["A2"].font = FONT_SUBTITLE
    ws2["A2"].alignment = Alignment(horizontal="center")

    for col, h in enumerate(h1, 1):
        cell = ws2.cell(row=4, column=col, value=h)
        cell.font = FONT_HEADER
        cell.fill = FILL_HEADER
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = THIN_BORDER

    for idx, s in enumerate(top30):
        row = 5 + idx
        fill = FILL_TOP1 if s["score"] >= 65 else FILL_TOP2

        set_c2 = lambda col, v, font=FONT_DATA, fmt=None: _set_cell(ws2, row, col, v, font, fmt, fill)
        set_c2(1, s["code"], Font(name="微軟正黑體", size=11, bold=True))
        set_c2(2, s["name"])
        set_c2(3, s["price"] if s["price"] else "—", fmt="#,##0.00" if s["price"] else None)
        set_c2(4, s["pb"], fmt="0.00")
        set_c2(5, s["pe"] if s["pe"] else "—", fmt="0.0" if s["pe"] else None)
        set_c2(6, s["dy"]/100 if s["dy"] else "—", fmt="0.0%" if s["dy"] else None)
        set_c2(7, s["eps"] if s["eps"] is not None else "—", fmt="0.00" if s["eps"] is not None else None)
        set_c2(8, s["score"], Font(name="微軟正黑體", size=14, bold=True, color=COLOR_RED))
        set_c2(9, get_rating(s["score"]), Font(name="微軟正黑體", size=10, bold=True, color=COLOR_RED))
        set_c2(10, s["reasons"], Font(name="微軟正黑體", size=9, color="636e72"))

    # ===== Sheet 3: 統計 =====
    ws3 = wb.create_sheet("統計")
    ws3.sheet_properties.tabColor = "0984e3"
    ws3.column_dimensions["A"].width = 35
    ws3.column_dimensions["B"].width = 15

    top_a = len([s for s in results if s["score"] >= 80])
    top_a2 = len([s for s in results if 65 <= s["score"] < 80])
    top_b = len([s for s in results if 50 <= s["score"] < 65])
    top_c = len([s for s in results if 35 <= s["score"] < 50])
    top_d = len([s for s in results if s["score"] < 35])

    avg_top50 = sum(s["score"] for s in results[:50]) / 50 if len(results) >= 50 else 0

    stats = [
        ("巴菲特價值股篩選統計", ""),
        ("", ""),
        ("資料日期", "2026-07-16 (收盤) + 2026 Q1 財報"),
        ("資料來源", "證交所 3 個公開 API"),
        ("分析檔數", len(results)),
        ("", ""),
        ("【評級分布】", ""),
        ("A+ 巴菲特最愛 (80+)", top_a),
        ("A  優質價值股 (65-79)", top_a2),
        ("B  值得關注 (50-64)", top_b),
        ("C  普通 (35-49)", top_c),
        ("D  不符合 (<35)", top_d),
        ("", ""),
        ("【榜單】", ""),
        ("TOP 30 門檻分數", results[29]["score"] if len(results) >= 30 else "—"),
        ("TOP 50 平均分數", f"{avg_top50:.1f}"),
    ]

    for row, (k, v) in enumerate(stats, 1):
        cell_a = ws3.cell(row=row, column=1, value=k)
        cell_a.font = Font(name="微軟正黑體", size=11, bold=True) if k.startswith("【") or k == "巴菲特價值股篩選統計" else Font(name="微軟正黑體", size=11)
        cell_a.border = THIN_BORDER
        if isinstance(v, int):
            cell_b = ws3.cell(row=row, column=2, value=v)
            cell_b.font = Font(name="微軟正黑體", size=11, bold=True, color=COLOR_RED)
            cell_b.alignment = Alignment(horizontal="center")
            cell_b.border = THIN_BORDER
        elif v:
            cell_b = ws3.cell(row=row, column=2, value=v)
            cell_b.font = Font(name="微軟正黑體", size=11)
            cell_b.border = THIN_BORDER

    wb.save(XLSX_PATH)
    print(f" Excel: {XLSX_PATH}")
    return XLSX_PATH


def create_html(results):
    """產生獨立 HTML 報表。"""
    print(" 產生 HTML...")

    def get_rating(score):
        if score >= 80:
            return "A+ 巴菲特最愛"
        if score >= 65:
            return "A  優質價值股"
        if score >= 50:
            return "B  值得關注"
        if score >= 35:
            return "C  普通"
        return "D  不符合"

    def fmt_num(value, digits=2, empty="—"):
        if value is None:
            return empty
        return f"{value:.{digits}f}"

    def fmt_price(value):
        return "—" if value is None else f"{value:.2f}"

    def fmt_dy(value):
        return "—" if value is None else f"{value:.1f}%"

    def row_class(score):
        if score >= 65:
            return "row-hot"
        if score >= 50:
            return "row-warm"
        return ""

    total = len(results)
    top30 = results[:30]
    top100 = results[:100]
    avg_score = (sum(r["score"] for r in results) / total) if total else 0
    grade_counts = {
        "A+ 巴菲特最愛": sum(1 for r in results if r["score"] >= 80),
        "A  優質價值股": sum(1 for r in results if 65 <= r["score"] < 80),
        "B  值得關注": sum(1 for r in results if 50 <= r["score"] < 65),
        "C  普通": sum(1 for r in results if 35 <= r["score"] < 50),
        "D  不符合": sum(1 for r in results if r["score"] < 35),
    }

    def build_rows(items):
        rows = []
        for s in items:
            rows.append(
                f"""
                <tr class="{row_class(s['score'])}">
                    <td class="code"><a href="https://goodinfo.tw/StockInfo/StockDetail.asp?STOCK_ID={html_escape(str(s['code']))}" target="_blank" style="color:#ff7675;text-decoration:none" title="點我看線圖">{html_escape(str(s['code']))}</a></td>
                    <td class="name">{html_escape(str(s['name']))}</td>
                    <td class="num">{fmt_price(s['price'])}</td>
                    <td class="num">{fmt_num(s['pb'])}</td>
                    <td class="num">{fmt_num(s['pe'], 1)}</td>
                    <td class="num">{fmt_dy(s['dy'])}</td>
                    <td class="num">{fmt_num(s['eps'])}</td>
                    <td class="score">{s['score']}</td>
                    <td class="grade">{html_escape(get_rating(s['score']))}</td>
                    <td class="reason">{html_escape(s['reasons'] or "—")}</td>
                </tr>
                """
            )
        return "\n".join(rows)

    grade_cards = "\n".join(
        f"""
        <div class="grade-card">
            <div class="grade-label">{html_escape(label)}</div>
            <div class="grade-value">{count}</div>
        </div>
        """
        for label, count in grade_counts.items()
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>巴菲特價值股篩選（台股版）</title>
    <style>
        :root {{
            --bg: #f5f7fb;
            --panel: rgba(255, 255, 255, 0.9);
            --text: #1f2d3d;
            --muted: #6b7280;
            --line: #e5e7eb;
            --brand: #2d3436;
            --accent: #d63031;
            --accent-soft: rgba(214, 48, 49, 0.12);
            --warm-soft: rgba(230, 126, 34, 0.12);
            --shadow: 0 20px 50px rgba(15, 23, 42, 0.08);
        }}
        * {{ box-sizing: border-box; }}
        body {{
            margin: 0;
            font-family: "Microsoft JhengHei", "PingFang TC", "Noto Sans TC", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at top left, rgba(214, 48, 49, 0.08), transparent 35%),
                radial-gradient(circle at top right, rgba(230, 126, 34, 0.08), transparent 28%),
                linear-gradient(180deg, #ffffff 0%, var(--bg) 100%);
        }}
        .wrap {{
            max-width: 1500px;
            margin: 0 auto;
            padding: 28px 18px 56px;
        }}
        .hero {{
            position: relative;
            overflow: hidden;
            background: var(--panel);
            border: 1px solid rgba(255, 255, 255, 0.8);
            border-radius: 28px;
            padding: 30px 30px 26px;
            box-shadow: var(--shadow);
            backdrop-filter: blur(10px);
        }}
        .hero::after {{
            content: "";
            position: absolute;
            inset: auto -60px -80px auto;
            width: 220px;
            height: 220px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(214, 48, 49, 0.18), transparent 70%);
            pointer-events: none;
        }}
        .title {{
            margin: 0;
            font-size: clamp(30px, 4vw, 46px);
            line-height: 1.08;
            letter-spacing: 0.02em;
            color: var(--brand);
        }}
        .subtitle {{
            margin: 10px 0 0;
            color: var(--muted);
            font-size: 14px;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
            margin-top: 22px;
        }}
        .stat {{
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid var(--line);
            border-radius: 18px;
            padding: 16px 18px;
            box-shadow: 0 10px 24px rgba(15, 23, 42, 0.04);
        }}
        .stat-label {{
            color: var(--muted);
            font-size: 13px;
            margin-bottom: 6px;
        }}
        .stat-value {{
            font-size: 28px;
            font-weight: 800;
            color: var(--brand);
        }}
        .section {{
            margin-top: 22px;
            background: var(--panel);
            border: 1px solid rgba(255, 255, 255, 0.85);
            border-radius: 26px;
            padding: 22px;
            box-shadow: var(--shadow);
            backdrop-filter: blur(10px);
        }}
        .section h2 {{
            margin: 0 0 14px;
            font-size: 22px;
            color: var(--brand);
        }}
        .section-meta {{
            margin: -4px 0 16px;
            color: var(--muted);
            font-size: 13px;
        }}
        .table-wrap {{
            overflow-x: auto;
            border-radius: 18px;
            border: 1px solid var(--line);
            background: #fff;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            min-width: 1220px;
        }}
        thead th {{
            position: sticky;
            top: 0;
            z-index: 1;
            background: linear-gradient(180deg, #2d3436 0%, #3b4547 100%);
            color: #fff;
            font-size: 13px;
            text-align: center;
            padding: 13px 10px;
            white-space: nowrap;
        }}
        tbody td {{
            border-top: 1px solid var(--line);
            padding: 10px 10px;
            font-size: 13px;
            vertical-align: top;
            background: #fff;
        }}
        tbody tr:hover td {{
            background: #f8fafc;
        }}
        .row-hot td {{
            background: var(--accent-soft);
        }}
        .row-warm td {{
            background: var(--warm-soft);
        }}
        .code, .num, .score {{
            text-align: center;
            white-space: nowrap;
        }}
        .code {{
            font-weight: 700;
        }}
        .name {{
            font-weight: 600;
            white-space: nowrap;
        }}
        .score {{
            font-weight: 800;
            color: var(--accent);
            font-size: 16px;
        }}
        .grade {{
            white-space: nowrap;
            font-weight: 700;
        }}
        .reason {{
            color: #475569;
            line-height: 1.5;
        }}
        .grade-grid {{
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 14px;
        }}
        .grade-card {{
            border: 1px solid var(--line);
            border-radius: 18px;
            padding: 18px;
            background: linear-gradient(180deg, #ffffff, #f8fafc);
        }}
        .grade-label {{
            color: var(--muted);
            font-size: 13px;
            line-height: 1.4;
        }}
        .grade-value {{
            margin-top: 8px;
            font-size: 28px;
            font-weight: 800;
            color: var(--brand);
        }}
        .footer-note {{
            margin-top: 12px;
            color: var(--muted);
            font-size: 12px;
            text-align: right;
        }}
        @media (max-width: 1100px) {{
            .stats, .grade-grid {{
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }}
        }}
        @media (max-width: 700px) {{
            .wrap {{ padding: 14px 12px 34px; }}
            .hero, .section {{ padding: 18px 14px; border-radius: 20px; }}
            .stats, .grade-grid {{
                grid-template-columns: 1fr;
            }}
            .title {{ font-size: 28px; }}
        }}
    </style>
</head>
<body>
    <div class="wrap">
        <section class="hero">
            <h1 class="title">巴菲特價值股篩選（台股版）</h1>
            <p class="subtitle">產生時間：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} ｜ 排序依據：巴菲特評分由高到低</p>
            <div class="stats">
                <div class="stat">
                    <div class="stat-label">總股票數</div>
                    <div class="stat-value">{total}</div>
                </div>
                <div class="stat">
                    <div class="stat-label">TOP30 數量</div>
                    <div class="stat-value">{len(top30)}</div>
                </div>
                <div class="stat">
                    <div class="stat-label">平均分數</div>
                    <div class="stat-value">{avg_score:.1f}</div>
                </div>
            </div>
        </section>

        <section class="section">
            <h2>🏆 巴菲特首選 TOP 30</h2>
            <div class="section-meta">只顯示前 30 名，並以分數高低排序。</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>代號</th>
                            <th>公司名稱</th>
                            <th>市價</th>
                            <th>P/B值</th>
                            <th>本益比</th>
                            <th>殖利率</th>
                            <th>EPS(近季)</th>
                            <th>巴菲特評分</th>
                            <th>評級</th>
                            <th>加分原因</th>
                        </tr>
                    </thead>
                    <tbody>
                        {build_rows(top30) if top30 else '<tr><td colspan="10" style="text-align:center;padding:24px;color:#64748b;">無符合資料</td></tr>'}
                    </tbody>
                </table>
            </div>
        </section>

        <section class="section">
            <h2>📊 評級分布</h2>
            <div class="grade-grid">
                {grade_cards}
            </div>
        </section>

        <section class="section">
            <h2>📋 全部評分清單 (TOP 100)</h2>
            <div class="section-meta">顯示前 100 名，方便快速檢視整體結果。</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>代號</th>
                            <th>公司名稱</th>
                            <th>市價</th>
                            <th>P/B值</th>
                            <th>本益比</th>
                            <th>殖利率</th>
                            <th>EPS(近季)</th>
                            <th>巴菲特評分</th>
                            <th>評級</th>
                            <th>加分原因</th>
                        </tr>
                    </thead>
                    <tbody>
                        {build_rows(top100) if top100 else '<tr><td colspan="10" style="text-align:center;padding:24px;color:#64748b;">無符合資料</td></tr>'}
                    </tbody>
                </table>
            </div>
            <div class="footer-note">資料來源：證交所公開 API ｜ 以本次分析結果自動生成</div>
        </section>
    </div>
</body>
</html>
"""

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print(f" HTML: {HTML_PATH}")
    return HTML_PATH


def _set_cell(ws, row, col, value, font=None, fmt=None, fill=None):
    c = ws.cell(row=row, column=col, value=value)
    if font: c.font = font
    if fmt: c.number_format = fmt
    if fill: c.fill = fill
    c.alignment = Alignment(horizontal="center", vertical="center")
    c.border = THIN_BORDER
    return c


def upload_github(file_path):
    """上傳到 GitHub xiaohu-tools repo"""
    try:
        import base64
        pat = json.load(open(os.path.expanduser("~/.openclaw/credentials/github.json")))["pat"]
        ctx = ssl.create_default_context()

        with open(file_path, "rb") as f:
            content = f.read()

        data = json.dumps({
            "message": f"buffett_value_stocks.xlsx {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "content": base64.b64encode(content).decode(),
        }).encode()

        req = urllib.request.Request(
            "https://api.github.com/repos/awlk27-oss/xiaohu-tools/contents/buffett_value_stocks.xlsx",
            data=data,
            headers={
                "Authorization": f"Bearer {pat}",
                "Content-Type": "application/json",
                "User-Agent": "openclaw-agent",
            },
            method="PUT",
        )
        resp = urllib.request.urlopen(req, timeout=30, context=ctx)
        result = json.loads(resp.read())
        url = result["content"]["download_url"]
        print(f" GitHub: {url}")
        return url
    except Exception as e:
        print(f" GitHub 上傳失敗: {e}")
        return None


def main():
    print("=" * 55)
    print(" 巴菲特價值股篩選工具 (台股版) v1.0")
    print(f" {datetime.now().strftime('%Y-%m-%d %H:%M')} UTC")
    print("=" * 55)

    pb_data, price_data, fin_data = fetch_all_data()
    if not pb_data:
        print("e 證交所 API 失敗")
        sys.exit(1)

    results = analyze(pb_data, price_data, fin_data)
    xlsx = create_excel(results)
    html_path = create_html(results)

    print("\n GitHub 上傳中...")
    link = upload_github(xlsx)

    print(f"\n{'='*55}")
    print(f" 完成!")
    print(f" Excel: {xlsx}")
    print(f" HTML: {html_path}")
    if link:
        print(f" 下載: {link}")

    top = [s for s in results if s["score"] >= 50][:10]
    if top:
        print(f"\n TOP 10 巴菲特價值股:")
        print(f" {'代號':>6} {'名稱':<10} {'評分':>4} {'P/B':>6} {'PE':>6} {'殖利率':>6}")
        print(f" {'-'*42}")
        for s in top:
            dy = f"{s['dy']:.1f}%" if s["dy"] else "N/A"
            pe = f"{s['pe']:.1f}" if s["pe"] else "N/A"
            print(f" {s['code']:>6} {s['name']:<10} {s['score']:>4} {s['pb']:>6.2f} {pe:>6} {dy:>6}")
    print(f"{'='*55}")


if __name__ == "__main__":
    main()
