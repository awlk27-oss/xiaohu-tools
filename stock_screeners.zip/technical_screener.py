#!/usr/bin/env python3
"""
技術分析選股工具 v1.0
使用證交所公開 API

功能：
1. 全部掃描 — 依今日收盤技術面篩出偏多股票
2. 自選股 — 輸入代號，抓歷史K線算完整指標+買賣價

技術指標：
- 均線 MA5/MA20（判斷多空）
- KD 隨機指標（判斷超買超賣）
- RSI 相對強弱（判斷強弱勢）
- 支撐/壓力價位
"""

import json, sys, os, time, ssl, urllib.request
from datetime import datetime, timedelta

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(WORKSPACE, "technical_report.html")


def fetch_json(url):
    ctx = ssl.create_default_context()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=20, context=ctx)
        return json.loads(resp.read())
    except: return None


def get_twse_stock_day(stock_id, year_months):
    """抓證交所個股日K線（可多個月）"""
    prices = []
    for ym in year_months:
        url = f"https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={ym}01&stockNo={stock_id}"
        data = fetch_json(url)
        if data and data.get("stat") == "OK" and data.get("data"):
            for row in data["data"]:
                try:
                    date_str = row[0].replace("/", "-")  # 115/07/16 -> 115-07-16
                    prices.append({
                        "date": date_str,
                        "open": float(row[3].replace(",", "")),
                        "high": float(row[4].replace(",", "")),
                        "low": float(row[5].replace(",", "")),
                        "close": float(row[6].replace(",", "")),
                    })
                except: pass
    return prices


def calc_ma(prices, n):
    """算移動平均線"""
    vals = [p["close"] for p in prices]
    if len(vals) < n: return [None] * len(vals)
    result = []
    for i in range(len(vals)):
        if i < n - 1: result.append(None)
        else: result.append(sum(vals[i-n+1:i+1]) / n)
    return result


def calc_kd(prices, n=9):
    """算 KD 隨機指標"""
    closes = [p["close"] for p in prices]
    if len(closes) < n: return [None] * len(closes), [None] * len(closes)
    k_vals = []; d_vals = []
    k = 50; d = 50
    for i in range(len(closes)):
        if i < n - 1: k_vals.append(None); d_vals.append(None); continue
        hh = max(p["high"] for p in prices[i-n+1:i+1])
        ll = min(p["low"] for p in prices[i-n+1:i+1])
        rsv = (closes[i] - ll) / (hh - ll) * 100 if hh != ll else 50
        k = 2/3 * k + 1/3 * rsv
        d = 2/3 * d + 1/3 * k
        k_vals.append(k); d_vals.append(d)
    return k_vals, d_vals


def calc_rsi(prices, n=14):
    """算 RSI"""
    closes = [p["close"] for p in prices]
    if len(closes) <= n: return [None] * len(closes)
    rsis = []
    for i in range(len(closes)):
        if i < n: rsis.append(None); continue
        gains = 0; losses = 0
        for j in range(i-n+1, i+1):
            diff = closes[j] - closes[j-1]
            if diff > 0: gains += diff
            else: losses -= diff
        if losses == 0: rsis.append(100)
        else: rsis.append(100 - 100 / (1 + gains / losses))
    return rsis


def calc_support_resistance(prices):
    """算支撐/壓力（近期低點高點）"""
    if len(prices) < 20: return None, None
    recent = prices[-20:]
    lows = [p["low"] for p in recent]
    highs = [p["high"] for p in recent]
    support = min(lows)
    resistance = max(highs)
    return support, resistance




def get_finmind_stock_data(stock_id):
    """用 FinMind API 抓歷史股價（補上櫃/ETF 資料）"""
    import os as _os
    _TOKEN = ""
    _tk = _os.path.expanduser("~/.openclaw/credentials/finmind.json")
    if _os.path.exists(_tk):
        try:
            with open(_tk) as _f: _TOKEN = json.load(_f)["token"]
        except: pass
    if not _TOKEN:
        return []
    
    _ctx = ssl.create_default_context()
    _prices = []
    for _m in range(3):
        from datetime import datetime as _dt, timedelta as _td
        _d = _dt.now() - _td(days=_m*30)
        _start = _d.strftime("%Y-%m-01")
        _end = (_dt(_d.year + _d.month // 12, _d.month % 12 + 1, 1) - _td(days=1)) if _d.month < 12 else ""
        if _m == 0:
            _end = _dt.now().strftime("%Y-%m-%d")
        _url = f"https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockPrice&data_id={stock_id}&start_date={_start}&end_date={_end}&token={_TOKEN}"
        try:
            _req = urllib.request.Request(_url, headers={"User-Agent": "Mozilla/5.0"})
            _resp = urllib.request.urlopen(_req, timeout=15, context=_ctx)
            _data = json.loads(_resp.read())
            if _data.get("data"):
                for _r in _data["data"]:
                    try:
                        _prices.append({
                            "date": _r.get("date", ""),
                            "open": float(_r.get("open", 0) or 0),
                            "high": float(_r.get("max", 0) or 0),
                            "low": float(_r.get("min", 0) or 0),
                            "close": float(_r.get("close", 0) or 0),
                        })
                    except: pass
        except: pass
        time.sleep(0.5)
    
    # 去重+排序
    seen = set()
    _prices.sort(key=lambda x: x["date"])
    _dedup = []
    for _p in _prices:
        if _p["date"] not in seen:
            seen.add(_p["date"])
            _dedup.append(_p)
    return _dedup
def analyze_stock(stock_id, stock_name, prices, is_self_pick=False):
    """對單一股票分析技術指標"""
    if len(prices) < 5: return None

    ma5 = calc_ma(prices, 5)
    ma20 = calc_ma(prices, 20)
    k_vals, d_vals = calc_kd(prices)
    rsis = calc_rsi(prices)
    support, resistance = calc_support_resistance(prices)

    last = prices[-1]
    last_c = last["close"]
    last_ma5 = ma5[-1] if ma5[-1] is not None else last_c
    last_ma20 = ma20[-1] if ma20[-1] is not None else last_c
    last_k = k_vals[-1] if k_vals[-1] is not None else 50
    last_d = d_vals[-1] if d_vals[-1] is not None else 50
    last_rsi = rsis[-1] if rsis[-1] is not None else 50

    score = 0
    signals = []
    price_targets = []

    # 均線判斷
    if last_c > last_ma5 > last_ma20:
        score += 25; signals.append("多頭排列 📈")
    elif last_c > last_ma5:
        score += 15; signals.append("站上5日線")
    elif last_c < last_ma5 and last_c > last_ma20:
        score += 5; signals.append("20日線有撐")
    elif last_c < last_ma5 < last_ma20:
        score -= 10; signals.append("空頭排列 📉")
    else:
        score += 0; signals.append("震盪")

    # KD 判斷
    if last_k > 80:
        signals.append("K值偏高⚠️")
    elif last_k < 20:
        score += 15; signals.append(f"K值{last_k:.0f} 超賣區")
    if last_k > last_d and last_k < 50:
        score += 15; signals.append("KD黃金交叉")
    elif last_k < last_d and last_k > 50:
        score -= 10; signals.append("KD死亡交叉")

    # RSI 判斷
    if last_rsi > 70:
        signals.append(f"RSI={last_rsi:.0f} 過熱⚠️")
    elif last_rsi < 30:
        score += 20; signals.append(f"RSI={last_rsi:.0f} 超賣區")
    elif 40 <= last_rsi <= 60:
        score += 10; signals.append(f"RSI={last_rsi:.0f} 中立")

    # 支撐壓力
    if support and resistance:
        if last_c <= support * 1.02:
            score += 15; signals.append(f"接近支撐{support:.2f}")
        price_targets.append(f"支撐 {support:.2f}")
        price_targets.append(f"壓力 {resistance:.2f}")
        buy_zone = f"買进區 {support:.2f}~{support*1.03:.2f}"
        sell_zone = f"賣出區 {resistance*0.97:.2f}~{resistance:.2f}"
        price_targets.append(buy_zone)
        price_targets.append(sell_zone)

    score = max(-50, min(100, score))

    # 建議
    if score >= 40:
        suggestion = "偏多操作 ✅"
    elif score >= 15:
        suggestion = "中立偏多"
    elif score >= -5:
        suggestion = "中立觀望"
    elif score >= -20:
        suggestion = "中立偏空"
    else:
        suggestion = "偏空謹慎 ⚠️"

    return {
        "code": stock_id, "name": stock_name,
        "close": last_c, "change_pct": (last_c - prices[-2]["close"]) / prices[-2]["close"] * 100 if len(prices) >= 2 else 0,
        "ma5": last_ma5, "ma20": last_ma20,
        "k": last_k, "d": last_d, "rsi": last_rsi,
        "support": support, "resistance": resistance,
        "score": score, "signals": signals,
        "price_targets": price_targets,
        "suggestion": suggestion,
    }


def create_html(all_results, self_pick_results):
    """產出 HTML 報表"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    html = "<!doctype html>\n<html lang='zh-Hant'>\n<head>\n"
    html += "<meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>\n"
    html += "<title>技術分析選股報告</title>\n<style>\n"
    html += "*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top left,rgba(214,48,49,.12),transparent 24%),radial-gradient(circle at top right,rgba(9,132,227,.12),transparent 22%),linear-gradient(180deg,#0b1118,#111a23);color:#ecf0f1;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans TC','Microsoft JhengHei',sans-serif}"
    html += ".wrap{max-width:1400px;margin:0 auto;padding:28px 18px}"
    html += ".hero{background:linear-gradient(135deg,rgba(45,52,54,.98),rgba(27,39,51,.98));border:1px solid rgba(255,255,255,.07);border-radius:24px;padding:28px;margin-bottom:22px}"
    html += "h1{margin:0 0 8px;font-size:34px}.sub{color:#b2bec3;font-size:14px}"
    html += ".sec{background:rgba(12,18,24,.78);border:1px solid rgba(255,255,255,.06);border-radius:22px;overflow:hidden;margin-top:22px}"
    html += ".sh{padding:18px 22px;background:linear-gradient(90deg,rgba(45,52,54,.95),rgba(27,39,51,.95));border-bottom:1px solid rgba(255,255,255,.06)}"
    html += ".sh h2{margin:0 0 4px;font-size:20px}.sh p{margin:0;color:#b2bec3;font-size:13px}"
    html += ".tw{overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:900px}"
    html += "th,td{padding:10px 12px;text-align:left;border-bottom:1px solid rgba(255,255,255,.06)}"
    html += "th{color:#f5f6fa;background:rgba(45,52,54,.95);position:sticky;top:0;font-size:13px}"
    html += "tr:nth-child(odd){background:rgba(255,255,255,.03)}tr:nth-child(even){background:rgba(255,255,255,.015)}"
    html += ".n{text-align:right}.r{color:#d63031;font-weight:700}.g{color:#00b894}"
    html += ".tag{display:inline-block;padding:2px 6px;border-radius:4px;font-size:11px;font-weight:700}"
    html += ".t1{background:rgba(214,48,49,.15);color:#ff7675;border:1px solid rgba(214,48,49,.3)}"
    html += ".t2{background:rgba(253,203,110,.15);color:#ffeaa7;border:1px solid rgba(253,203,110,.3)}"
    html += ".t3{background:rgba(0,184,148,.15);color:#55efc4;border:1px solid rgba(0,184,148,.3)}"
    html += "details{margin:0 22px 14px;padding:14px 0;border-bottom:1px solid rgba(255,255,255,.06)}"
    html += "details:last-child{border-bottom:none;margin-bottom:0}"
    html += "summary{cursor:pointer;font-weight:700;padding:8px 0;color:#ff7675}"
    html += ".sg{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;padding:8px 0}"
    html += ".sg div{padding:6px 12px;background:rgba(255,255,255,.04);border-radius:8px;font-size:14px}"
    html += "@media(max-width:900px){.sg{grid-template-columns:1fr}h1{font-size:28px}}"
    html += "</style>\n</head>\n<body>\n<div class='wrap'>\n"

    # Hero
    good = sum(1 for r in all_results if r["score"] >= 40)
    bad = sum(1 for r in all_results if r["score"] < -5)
    html += f"<div class='hero'><h1>技術分析選股報告</h1>"
    html += f"<div class='sub'>產生時間：{ts} | 資料來源：證交所公開 API</div>"
    html += f"<div style='margin-top:16px;display:grid;grid-template-columns:repeat(3,1fr);gap:14px'>"
    html += f"<div style='background:rgba(255,255,255,.04);border-radius:14px;padding:14px'><div>掃描檔數</div><div style='font-size:28px;font-weight:800'>{len(all_results)}</div></div>"
    html += f"<div style='background:rgba(255,255,255,.04);border-radius:14px;padding:14px;border:1px solid rgba(214,48,49,.3)'><div>偏多</div><div style='font-size:28px;font-weight:800;color:#ff7675'>{good}</div></div>"
    html += f"<div style='background:rgba(255,255,255,.04);border-radius:14px;padding:14px;border:1px solid rgba(0,184,148,.3)'><div>偏空</div><div style='font-size:28px;font-weight:800;color:#55efc4'>{bad}</div></div>"
    html += "</div></div>\n"

    # 自選股區
    if self_pick_results:
        html += "<div class='sec'><div class='sh'><h2>自選股分析</h2><p>完整歷史K線技術指標 + 買賣建議</p></div>"
        for s in self_pick_results:
            tag = "t1" if s["score"] >= 40 else "t2" if s["score"] >= 0 else "t3"
            clr = "#ff7675" if s["score"] >= 40 else "#ffeaa7" if s["score"] >= 0 else "#55efc4"
            html += "<details><summary>"
            html += f"<span style='font-size:18px'>{s['code']} {s['name']}</span>"
            html += f" <span class='tag {tag}'>評分 {s['score']}</span>"
            html += f" <span class='tag {tag}'>{s['suggestion']}</span>"
            html += f" <span style='float:right;color:{clr}'>收盤 {s['close']:.2f} ({s['change_pct']:+.2f}%)</span>"
            html += "</summary>"

            # 指標
            html += "<div style='padding:8px 0'><div class='sg'>"
            html += f"<div>MA5 <b>{s['ma5']:.2f}</b> {'✅ 站上' if s['close']>s['ma5'] else '⚠️ 跌破'}</div>"
            html += f"<div>MA20 <b>{s['ma20']:.2f}</b> {'✅ 站上' if s['close']>s['ma20'] else '⚠️ 跌破'}</div>"
            html += f"<div>K值 <b>{s['k']:.1f}</b> {'⚠️ 過熱' if s['k']>80 else '✅ 偏低' if s['k']<20 else '中立'}</div>"
            html += f"<div>D值 <b>{s['d']:.1f}</b></div>"
            clr_rsi = "#ff7675" if s['rsi'] >= 70 else "#55efc4" if s['rsi'] <= 30 else "#ffeaa7"
            html += f"<div>RSI(14) <b style='color:{clr_rsi}'>{s['rsi']:.1f}</b></div>"
            html += f"<div>訊號: {' '.join(f'<span class=\"tag t2\">{x}</span>' for x in s['signals'][:3])}</div>"
            html += "</div></div>"

            # 買賣價
            html += "<div style='padding:8px 0'><div class='sg'>"
            for t in s["price_targets"]:
                c = "#ff7675" if "買" in t else "#55efc4" if "賣" in t else "#b2bec3"
                html += f"<div style='color:{c}'>{t}</div>"
            html += "</div></div>"
            html += "</details>"
        html += "</div>\n"

    # 全部掃描
    html += "<div class='sec'><div class='sh'><h2>全部掃描結果</h2><p>依技術評分由高到低（偏多➡偏空）</p></div><div class='tw'><table>"
    html += "<tr><th>代號</th><th>名稱</th><th class=n>收盤</th><th class=n>漲跌%</th><th class=n>MA5</th><th class=n>MA20</th><th class=n>K值</th><th class=n>D值</th><th class=n>RSI</th><th class=n>評分</th><th>訊號</th><th>建議</th></tr>"

    def n(v, d=2):
        if v is None: return "—"
        return f"{v:.{d}f}"

    for s in all_results:
        tag = "t1" if s["score"] >= 40 else "t2" if s["score"] >= 0 else "t3"
        col = "#ff7675" if s["score"] >= 40 else "#ffeaa7" if s["score"] >= 0 else "#55efc4"
        signals_short = s["signals"][:2]
        html += "<tr>"
        html += f"<td><a href='https://goodinfo.tw/StockInfo/StockDetail.asp?STOCK_ID={s['code']}' target='_blank' style='color:#fff;font-weight:800;text-decoration:none'>{s['code']}</a></td>"
        html += f"<td>{s['name']}</td>"
        html += f"<td class=n>{n(s['close'])}</td>"
        chg_clr = "#ff7675" if s["change_pct"] >= 0 else "#55efc4"
        html += f"<td class=n style='color:{chg_clr}'>{n(s['change_pct'])}%</td>"
        html += f"<td class=n>{n(s['ma5'])}</td><td class=n>{n(s['ma20'])}</td>"
        html += f"<td class=n>{n(s['k'],1)}</td><td class=n>{n(s['d'],1)}</td>"
        rsi_clr = "#ff7675" if s['rsi'] >= 70 else "#55efc4" if s['rsi'] <= 30 else "#ffeaa7"
        html += f"<td class=n style='color:{rsi_clr}'>{n(s['rsi'],1)}</td>"
        html += f"<td class=n style='font-weight:800;color:{col}'>{s['score']}</td>"
        html += f"<td><span class='tag t2'>{signals_short[0] if signals_short else '—'}</span></td>"
        html += f"<td><span class='tag {tag}'>{s['suggestion']}</span></td>"
        html += "</tr>"

    html += "</table></div></div>\n<div class='ft' style='color:#b2bec3;font-size:12px;padding:20px 4px 0;text-align:right'>⚠️ 技術分析僅供參考，不構成投資建議</div>\n"
    html += "</div>\n</body>\n</html>"

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print(f" HTML: {HTML_PATH}")


def main():
    print("=" * 55)
    print(" 技術分析選股工具 v1.0")
    print(f" {datetime.now().strftime('%Y-%m-%d %H:%M')} UTC")
    print("=" * 55)

    # 步驟1: 抓今日所有股票資料（1 call）
    print("\n 抓取今日行情...")
    today_data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL")
    if not today_data:
        print("e 證交所 API 失敗"); sys.exit(1)
    print(f" {len(today_data)} 筆")

    # 步驟2: 自選股
    self_pick_codes = []
    if len(sys.argv) > 1:
        self_pick_codes = [c.strip() for c in sys.argv[1:] if c.strip()]
        print(f"  自選股：{', '.join(self_pick_codes)}")
    else:
        # 建立名稱→代號對照表
        name_to_code = {}
        for r in today_data:
            code = r.get("Code", "")
            name = r.get("Name", "").strip()
            if code and name:
                name_to_code[name] = code
                name_to_code[name.replace(" ", "")] = code
        
        print("\n 輸入股票代號或名稱（多個用逗號分隔，留空=預設持股）")
        inp = input("  > ").strip()
        if inp:
            parts = [p.strip() for p in inp.replace("，", ",").split(",") if p.strip()]
            for p in parts:
                # 先查是不是名稱
                if p in name_to_code:
                    self_pick_codes.append(name_to_code[p])
                # 再查是不是代號
                elif p.upper() in name_to_code.values() or p.upper() in [c for c in name_to_code.values()]:
                    self_pick_codes.append(p.upper())
                else:
                    # 模糊比對名稱
                    found = False
                    for n, c in name_to_code.items():
                        if p in n:
                            self_pick_codes.append(c)
                            found = True
                            break
                    if not found:
                        print(f"  ⚠️ 找不到「{p}」，跳過")
            print(f"  自選股：{', '.join(self_pick_codes)}")
        else:
            # 從持股清單
            self_pick_codes = ["0056", "0052", "00878", "00919", "00679B",
                              "1231", "1227", "1593", "2104", "4714",
                              "5457", "6185", "6469", "7723"]
            print(f"  使用預設持股清單：{', '.join(self_pick_codes)}")

    # 步驟3: 全掃（只用今日資料做快速技術面評分）
    print("\n 全掃技術面分析...")
    results = []
    code_name_map = {}
    for r in today_data:
        code = r.get("Code", "")
        name = r.get("Name", "").strip()
        try:
            close = float(r.get("ClosingPrice", 0) or 0)
            if close <= 0: continue
        except: continue
        code_name_map[code] = name

        # 從今日資料模擬技術面（只用收盤價+開高低來算）
        open_p = float(r.get("OpeningPrice", 0) or 0)
        high = float(r.get("HighestPrice", 0) or 0)
        low = float(r.get("LowestPrice", 0) or 0)
        chg = r.get("Change", "0")
        try: change_pct = float(chg) / (close - float(chg)) * 100 if close != float(chg) else 0
        except: change_pct = 0

        score = 0; signals = []

        # 當日多空判斷
        body = abs(close - open_p)
        upper_shadow = high - max(close, open_p)
        lower_shadow = min(close, open_p) - low
        body_pct = body / (high - low) * 100 if (high - low) > 0 else 0

        if close > open_p and body_pct > 60:
            score += 15; signals.append("實體紅K")
        elif close > open_p:
            score += 5; signals.append("收紅")
        elif close < open_p and body_pct > 60:
            score -= 10; signals.append("實體黑K")

        if lower_shadow > body * 1.5 and close > open_p:
            score += 10; signals.append("下影線支撐")
        if upper_shadow > body * 1.5 and close < open_p:
            score -= 10; signals.append("上影線壓力")

        if change_pct > 2:
            score += 10; signals.append(f"漲{change_pct:.1f}%")
        elif change_pct < -2:
            score -= 10

        # 成交量判斷 (粗略)
        vol_str = r.get("TradeVolume", "0")
        try:
            vol = float(vol_str)
            if vol > 50000000: score += 5; signals.append("量能充足")
        except: pass

        score = max(-30, min(80, score))
        results.append({
            "code": code, "name": name, "close": close,
            "change_pct": change_pct, "ma5": close, "ma20": close,
            "k": 50, "d": 50, "rsi": 50,
            "support": None, "resistance": None,
            "score": score, "signals": signals,
            "price_targets": [], "suggestion": "—",
        })

    results.sort(key=lambda r: r["score"], reverse=True)
    print(f" {len(results)} 檔完成")

    # 步驟4: 自選股詳細分析（抓歷史K線）
    self_pick_results = []
    if self_pick_codes:
        print(f"\n 自選股詳細分析 ({len(self_pick_codes)} 檔)...")
        today = datetime.now()
        year_months = []
        for m in range(3):
            y = today.year
            mo = today.month - m
            if mo <= 0: mo += 12; y -= 1
            is_roc = y - 1911
            year_months.append(f"{is_roc}{mo:02d}")

        for i, code in enumerate(self_pick_codes):
            name = code_name_map.get(code, "")
            prices = get_twse_stock_day(code, year_months)
            if len(prices) < 5:
                prices = get_finmind_stock_data(code)
            if len(prices) < 5:
                print(f"  ⚠️ {code} {name}: 歷史資料不足 ({len(prices)}筆)")
                continue
            result = analyze_stock(code, name, prices, is_self_pick=True)
            if result:
                self_pick_results.append(result)
                print(f"  ✅ {code} {name}: {prices[-1]['close']:.2f} 評分{result['score']}")

    # 步驟5: 產出 HTML
    print("\n 產出 HTML...")
    create_html(results, self_pick_results)

    print(f"\n{'='*55}")
    print(f" 完成！")
    print(f" 全部掃描：{len(results)} 檔")
    print(f" 偏多訊號：{sum(1 for r in results if r['score'] >= 20)} 檔")
    print(f" 自選分析：{len(self_pick_results)} 檔")
    print(f" HTML：{HTML_PATH}")
    print(f"{'='*55}")
    print(" ⚠️ 技術分析僅供參考，不構成投資建議")


if __name__ == "__main__":
    main()
