#!/usr/bin/env python3
"""
MiniMax Music Generator — 直接 call MiniMax Music API
走老大 Pay as You Go 的 $5

用法：
  python3 minimax_music.py "一首輕快的鋼琴曲"
  python3 minimax_music.py "熱血的搖滾樂" "歌詞可選"
  python3 minimax_music.py --list-styles

需要先設定 MiniMax API Key：
  python3 minimax_music.py --set-key "你的API Key"
"""

import json, ssl, urllib.request, urllib.parse, os, sys, time, base64
from datetime import datetime

CONFIG_PATH = os.path.expanduser("~/.openclaw/credentials/minimax_music.json")
API_BASE = "https://api.minimax.io/v1"


def load_key():
    """讀取已存的 MiniMax API Key"""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f).get("api_key", "")
        except:
            pass
    return ""


def save_key(api_key):
    """儲存 API Key"""
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump({"api_key": api_key}, f)
    os.chmod(CONFIG_PATH, 0o600)
    print(" API Key 已儲存")


def call_minimax_api(endpoint, payload, api_key):
    """call MiniMax API"""
    ctx = ssl.create_default_context()
    url = f"{API_BASE}/{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "xiaohu-music/1.0",
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=120, context=ctx)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  HTTP {e.code}: {body[:300]}")
        return None
    except Exception as e:
        print(f"  錯誤: {e}")
        return None


def list_styles():
    """列出風格"""
    print("\n MiniMax Music 風格參考")
    print("  " + "=" * 50)
    print("  流行 / Pop")
    print("  搖滾 / Rock")
    print("  電子 / Electronic")
    print("  古典 / Classical")
    print("  爵士 / Jazz")
    print("  民謠 / Folk")
    print("  嘻哈 / Hip-Hop")
    print("  R&B")
    print("  重金屬 / Metal")
    print("  放克 / Funk")
    print("  藍調 / Blues")
    print("  鄉村 / Country")
    print("  雷鬼 / Reggae")
    print("  電影配樂 / Cinematic")
    print("  遊戲配樂 / Gaming")
    print("  中國風 / Chinese")
    print("  日式 / Japanese")
    print("  搖籃曲 / Lullaby")
    print("  環境音樂 / Ambient")
    print("  Lo-fi")
    print("  " + "=" * 50)


def generate_music(prompt, lyrics=None, style=None, duration=30):
    """生成音樂"""
    api_key = load_key()
    if not api_key:
        print("❌ 請先設定 API Key")
        print("   執行: python3 minimax_music.py --set-key '你的Key'")
        print("   到 https://platform.minimax.io 取得 API Key")
        return None

    print(f"\n🎵 正在生成音樂...")
    print(f"   提示詞: {prompt}")
    if lyrics: print(f"   歌詞: {lyrics[:50]}...")
    print(f"   時長: {duration}秒")
    print(f"   預計費用: $0.15 (從 $5 扣)")
    print()

    payload = {
        "model": "music-01",
        "prompt": prompt,
        "duration_seconds": min(duration, 300),  # 最多5分鐘
    }
    if lyrics:
        payload["lyrics"] = lyrics
        payload["lyrics_type"] = "user"
    if style:
        payload["prompt"] = f"{style}風格：{prompt}"

    result = call_minimax_api("music/generate", payload, api_key)
    if not result:
        print("❌ 生成失敗")
        return None

    print(f"  ✅ 生成成功!")
    print(f"  回應: {json.dumps(result, indent=2, ensure_ascii=False)[:500]}")
    
    # 檢查音檔
    audio_url = None
    if result.get("data") and isinstance(result["data"], list):
        for item in result["data"]:
            if isinstance(item, dict):
                audio_url = item.get("audio_url") or item.get("url") or item.get("audio")
                if audio_url:
                    break
    elif result.get("audio_url"):
        audio_url = result["audio_url"]
    elif result.get("url"):
        audio_url = result["url"]
    
    if audio_url:
        print(f"\n  🔗 音檔連結: {audio_url}")
        return audio_url
    else:
        print("  ⚠️ 沒找到音檔連結，完整回應如上")
        return result


def main():
    if len(sys.argv) < 2:
        print("=" * 55)
        print(" MiniMax Music Generator — 用 $5 生音樂")
        print("=" * 55)
        print()
        print(" 用法:")
        print("  python3 minimax_music.py \"提示詞\"")
        print("  python3 minimax_music.py \"提示詞\" \"歌詞\"")
        print("  python3 minimax_music.py --list-styles")
        print("  python3 minimax_music.py --set-key \"API_KEY\"")
        print()
        print(" 範例:")
        print('  python3 minimax_music.py "一首輕快的鋼琴曲"')
        print('  python3 minimax_music.py "熱血搖滾" "燃燒吧！我的小宇宙"')
        print()
        return

    if sys.argv[1] == "--set-key" and len(sys.argv) > 2:
        save_key(sys.argv[2])
        return
    if sys.argv[1] == "--list-styles":
        list_styles()
        return

    prompt = sys.argv[1]
    lyrics = sys.argv[2] if len(sys.argv) > 2 else None
    generate_music(prompt, lyrics)


if __name__ == "__main__":
    main()
