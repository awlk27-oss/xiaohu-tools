#!/usr/bin/env python3
"""
成長股動能選股工具 v1.0
使用證交所公開 API

條件：
1. EPS > 0（有賺錢）
2. 營業利益率 > 5%（本業賺）
3. 本益比合理 < 20（不要買太貴）
4. P/B 不要太高（不要太泡沫）
"""

import json, sys, os, time, ssl, urllib.request
from datetime import datetime

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
XLSX_PATH = os.path.join(WORKSPACE, "growth_stocks.xlsx")
HTML_PATH = os.path.join(WORKSPACE, "growth_report.html")


def fetch_json(url, retries=3):
    ctx = ssl.create_default_context()
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            resp = urllib.request.urlopen(req, timeout=20, context=ctx)
            return json.loads(resp.read())
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2)
                continue
            return None


def main():
    print("=" * 50)
    print(" 成長股動能選股工具 v1.0")
    print(f" {datetime.now().strftime('%Y-%m-%d %H:%M')} UTC")
    print("=" * 50)

    print("\n 從證交所抓資料...")
    pb_data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL")
    fin_data = fetch_json("https://openapi.twse.com.tw/v1/opendata/t187ap14_L")
    price_data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL")
    if not pb_data or not fin_data:
        print("e 證交所 API 失敗")
        sys.exit(1)

    price_map = {}
    for r in (price_data or []):
        try:
            code = r.get("Code", ""); close = float(r.get("ClosingPrice", 0) or 0)
            if close > 0: price_map[code] = close
        except: pass

    fin_map = {}
    for r in fin_data:
        try:
            code = r.get("公司代號", ""); eps = float(r.get("基本每股盈餘(元)", 0) or 0)
            rev = float(r.get("營業收入", 0) or 0); op = float(r.get("營業利益", 0) or 0)
            net = float(r.get("稅後淨利", 0) or 0)
            fin_map[code] = {"eps": eps, "revenue": rev, "op": op, "net": net}
        except: pass

    results = []
    for r in pb_data:
        code = r.get("Code", ""); name = r.get("Name", "").strip()
        pe_str = (r.get("PEratio", "") or "").strip()
        pb_str = (r.get("PBratio", "") or "").strip()
        dy_str = (r.get("DividendYield", "") or "").strip()

        if not pe_str: continue
        try:
            pe = float(pe_str) if pe_str else None
            pb = float(pb_str) if pb_str else None
            dy = float(dy_str) if dy_str else None
        except: continue

        fin = fin_map.get(code)
        if not fin: continue
        if fin["eps"] <= 0: continue  # EPS 為正
        if fin["revenue"] <= 0: continue

        op_margin = fin["op"] / fin["revenue"] * 100
        net_margin = fin["net"] / fin["revenue"] * 100

        # 條件：本業要賺錢
        if op_margin < 5: continue

        # 條件：本益比合理
        if pe and pe > 20: continue

        price = price_map.get(code)
        revenue_b = fin["revenue"] / 100000000  # 億

        score = 0; reasons = []

        # 高營益率
        if op_margin >= 20: score += 20; reasons.append(f"營益率{op_margin:.1f}% 優")
        elif op_margin >= 10: score += 15
        else: score += 10

        # 高 EPS
        if fin["eps"] >= 3: score += 20; reasons.append(f"EPS={fin['eps']:.2f} 強")
        elif fin["eps"] >= 1.5: score += 15
        else: score += 10

        # 低本益比
        if pe and pe < 10: score += 15; reasons.append(f"本益比={pe:.1f} 偏低")
        elif pe and pe < 15: score += 10

        # P/B 合理
        if pb and pb < 2: score += 10
        if pb and pb < 1.5: score += 5

        # 有配息加分
        if dy and dy >= 3: score += 10; reasons.append(f"殖利率{dy:.1f}%")
        elif dy and dy >= 1: score += 5

        # 營收規模加分
        if revenue_b >= 100: score += 10; reasons.append("大型股")
        elif revenue_b >= 10: score += 5

        score = min(100, max(0, score))
        results.append({
            "code": code, "name": name, "price": price,
            "pe": pe, "pb": pb, "dy": dy,
            "eps": fin["eps"], "op_margin": op_margin, "net_margin": net_margin,
            "revenue_b": revenue_b, "score": score,
            "reasons": "、".join(reasons) if reasons else "成長動能",
        })

    results.sort(key=lambda r: r["score"], reverse=True)
    print(f" 上市 {len(pb_data)} 筆 → 篩出 {len(results)} 檔成長股")

    # ==== Excel ====
    print(" 產生 Excel...")
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    ws = wb.active; ws.title = "成長股動能"; ws.sheet_properties.tabColor = "0984e3"
    widths = [8, 14, 8, 11, 11, 11, 11, 11, 11, 8, 30]
    for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w

    FONT_T = Font(name="微軟正黑體", bold=True, size=16, color="2d3436")
    FONT_S = Font(name="微軟正黑體", size=12, color="636e72")
    FONT_H = Font(name="微軟正黑體", bold=True, color="ffffff", size=11)
    FONT_D = Font(name="微軟正黑體", size=11); RED = "d63031"
    FILL_H = PatternFill(start_color="2d3436", end_color="2d3436", fill_type="solid")
    TB = Border(*(Side(style='thin', color='dfe6e9'),)*4)

    def sc(ws, r, c, v, font=None, fmt=None, fill=None):
        cell = ws.cell(row=r, column=c, value=v)
        if font: cell.font = font
        if fmt: cell.number_format = fmt
        cell.alignment = Alignment(horizontal="center", vertical="center"); cell.border = TB; return cell

    ws.merge_cells("A1:K1"); ws["A1"].value = "成長股動能選股"; ws["A1"].font = FONT_T; ws["A1"].alignment = Alignment(horizontal="center")
    ws.merge_cells("A2:K2"); ws["A2"].value = f"條件：EPS>0 + 營益率>5% + 本益比<20 | {ts}"; ws["A2"].font = FONT_S; ws["A2"].alignment = Alignment(horizontal="center")
    hdrs = ["代號", "名稱", "市價", "本益比", "P/B", "殖利率%", "EPS", "營益率%", "營收(億)", "評分", "備註"]
    hr = 4
    for col, h in enumerate(hdrs, 1): sc(ws, hr, col, h, font=FONT_H, fill=FILL_H)

    for i, s in enumerate(results):
        row = hr + 1 + i
        sfont = Font(name="微軟正黑體", size=14, bold=True, color=RED if s["score"] >= 60 else "2d3436")
        sc(ws, row, 1, s["code"], font=Font(name="微軟正黑體", size=11, bold=True))
        sc(ws, row, 2, s["name"], font=FONT_D)
        sc(ws, row, 3, s["price"] if s["price"] else "—", font=FONT_D, fmt="#,##0.00" if s["price"] else None)
        sc(ws, row, 4, s["pe"] if s["pe"] else "—", font=FONT_D, fmt="0.0")
        sc(ws, row, 5, s["pb"] if s["pb"] else "—", font=FONT_D, fmt="0.00")
        sc(ws, row, 6, s["dy"]/100 if s["dy"] else "—", font=FONT_D, fmt="0.0%")
        sc(ws, row, 7, s["eps"], font=FONT_D, fmt="0.00")
        sc(ws, row, 8, s["op_margin"], font=FONT_D, fmt="0.1")
        sc(ws, row, 9, s["revenue_b"], font=FONT_D, fmt="#,##0.0")
        sc(ws, row, 10, s["score"], font=sfont)
        sc(ws, row, 11, s["reasons"], font=Font(name="微軟正黑體", size=10, color="636e72"))

    wb.save(XLSX_PATH)
    print(f" Excel: {XLSX_PATH}")

    # ==== HTML ====
    print(" 產生 HTML...")
    html = "<!doctype html>\n<html lang='zh-Hant'>\n<head>\n"
    html += "<meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>\n"
    html += "<title>成長股動能選股報告</title>\n<style>\n"
    html += "*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top left,rgba(9,132,227,.16),transparent 24%),radial-gradient(circle at top right,rgba(0,184,148,.12),transparent 22%),linear-gradient(180deg,#0b1118,#111a23);color:#ecf0f1;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans TC','Microsoft JhengHei',sans-serif;line-height:1.5}"
    html += ".wrap{max-width:1400px;margin:0 auto;padding:28px 18px}"
    html += ".hero{background:linear-gradient(135deg,rgba(9,132,227,.95),rgba(27,39,51,.95));border:1px solid rgba(255,255,255,.07);border-radius:24px;padding:28px}"
    html += "h1{margin:0 0 8px;font-size:34px}.sub{color:#b2bec3;font-size:14px;margin-bottom:20px}"
    html += ".cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}"
    html += ".card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:18px;padding:18px}"
    html += ".l{color:#b2bec3;font-size:13px;margin-bottom:8px}.v{font-size:30px;font-weight:800}"
    html += ".sec{margin-top:22px;background:rgba(12,18,24,.78);border:1px solid rgba(255,255,255,.06);border-radius:22px;overflow:hidden}"
    html += ".sh{padding:18px 22px;background:linear-gradient(90deg,rgba(9,132,227,.95),rgba(27,39,51,.95));border-bottom:1px solid rgba(255,255,255,.06)}"
    html += ".sh h2{margin:0 0 4px;font-size:20px}.sh p{margin:0;color:#b2bec3;font-size:13px}"
    html += ".tw{overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:920px}"
    html += "th,td{padding:10px 12px;text-align:left;border-bottom:1px solid rgba(255,255,255,.06)}"
    html += "th{color:#f5f6fa;background:rgba(9,132,227,.9);position:sticky;top:0;font-size:13px}"
    html += "tr:nth-child(odd){background:rgba(255,255,255,.03)}tr:nth-child(even){background:rgba(255,255,255,.015)}tr:hover{background:rgba(255,255,255,.06)}"
    html += ".n{text-align:right;font-variant-numeric:tabular-nums}.r{color:#d63031;font-weight:700}.g{color:#00b894}"
    html += ".bg{display:inline-block;padding:3px 8px;border-radius:999px;font-size:11px;font-weight:700}"
    html += ".bg1{background:rgba(214,48,49,.12);color:#ff7675;border:1px solid rgba(214,48,49,.28)}"
    html += ".bg2{background:rgba(0,184,148,.12);color:#55efc4;border:1px solid rgba(0,184,148,.22)}"
    html += "@media(max-width:900px){.cards{grid-template-columns:1fr}h1{font-size:28px}table{min-width:760px}}"
    html += "</style>\n</head>\n<body>\n<div class='wrap'>\n"

    html += f"<div class='hero'><h1>成長股動能選股報告</h1><div class='sub'>產生時間：{ts} | 來源：證交所公開 API</div><div class='cards'>"
    html += f"<div class='card'><div class='l'>篩選結果</div><div class='v'>{len(results)}</div><div class='l'>符合 EPS>0 + 營益率>5% + PE<20</div></div>"
    avg_op = sum(s["op_margin"] for s in results) / len(results) if results else 0
    html += f"<div class='card'><div class='l'>平均營益率</div><div class='v'>{avg_op:.1f}%</div><div class='l'>本業賺錢能力</div></div>"
    avg_score = sum(s["score"] for s in results) / len(results) if results else 0
    html += f"<div class='card'><div class='l'>平均評分</div><div class='v'>{avg_score:.0f}</div><div class='l'>最高 {results[0]['score']}</div></div>"
    html += "</div></div>\n"

    html += "<div class='sec'><div class='sh'><h2>成長股清單</h2><p>依綜合評分由高到低</p></div><div class='tw'><table>"
    html += "<tr><th>代號</th><th>名稱</th><th class=n>市價</th><th class=n>本益比</th><th class=n>P/B</th><th class=n>殖利率</th><th class=n>EPS</th><th class=n>營益率%</th><th class=n>營收(億)</th><th class=n>評分</th><th>備註</th></tr>"

    def n(v, d=2):
        if v is None: return "—"
        return f"{v:.{d}f}"

    for s in results:
        html += '<tr>'
        html += f'<td><a href="https://goodinfo.tw/StockInfo/StockDetail.asp?STOCK_ID={s["code"]}" target="_blank" style="color:#fff;text-decoration:none;font-weight:800">{s["code"]}</a></td>'
        html += f'<td>{s["name"]}</td>'
        html += f'<td class=n>{n(s["price"])}</td>'
        html += f'<td class=n>{n(s["pe"],1)}</td>'
        html += f'<td class=n>{n(s["pb"])}</td>'
        html += f'<td class=n r>{s["dy"]:.1f}%</td>' if s["dy"] else f'<td class=n>—</td>'
        html += f'<td class=n>{n(s["eps"])}</td>'
        html += f'<td class=n r>{n(s["op_margin"],1)}%</td>'
        html += f'<td class=n>{n(s["revenue_b"],1)}</td>'
        clr = "#ff7675" if s["score"] >= 60 else "#ffeaa7"
        html += f'<td class=n style="font-weight:800;color:{clr}">{s["score"]}</td>'
        html += f'<td><span class="bg {"bg1" if s["score"]>=60 else "bg2"}">{s["reasons"][:20]}</span></td>'
        html += '</tr>'

    html += "</table></div></div>\n"
    html += "<div class='ft' style='color:#b2bec3;font-size:12px;padding:20px 4px 0;text-align:right'>紅色=上漲/正值 綠色=下跌/負值</div>\n"
    html += "</div>\n</body>\n</html>"

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print(f" HTML: {HTML_PATH}")

    print(f"\n 完成！共 {len(results)} 檔")
    print(f"\nTOP 10 成長股：")
    print(f" {'代號':>6} {'名稱':<8} {'營益率':>6} {'EPS':>6} {'評分':>4}")
    for s in results[:10]:
        print(f" {s['code']:>6} {s['name']:<8} {s['op_margin']:>5.1f}% {s['eps']:>5.2f} {s['score']:>4}")


if __name__ == "__main__":
    main()
