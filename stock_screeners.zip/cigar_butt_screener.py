#!/usr/bin/env python3
"""
台股菸屁股選股工具 v1.1
使用證交所公開 API，免 API key、免註冊

功能：
1. 從證交所抓上市股票 P/B 資料 + 股價
2. 篩選 P/B < 1（菸屁股候選）
3. 輸出 Excel 表格（3 個 Sheet），自動上傳 Dropbox

用法：
  python3 cigar_butt_screener.py
"""

import json, sys, os, time, ssl, urllib.request, urllib.parse
from datetime import datetime
from html import escape
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
XLSX_PATH = os.path.join(WORKSPACE, "cigar_butt_results.xlsx")
HTML_PATH = os.path.join(WORKSPACE, "cigar_butt_report.html")

COLOR_RED = "d63031"
FILL_RED = PatternFill(start_color="ffe0e0", end_color="ffe0e0", fill_type="solid")
FILL_HEADER = PatternFill(start_color="2d3436", end_color="2d3436", fill_type="solid")
FONT_HEADER = Font(name="微軟正黑體", bold=True, color="ffffff", size=12)
FONT_TITLE = Font(name="微軟正黑體", bold=True, size=16, color="2d3436")
FONT_SUBTITLE = Font(name="微軟正黑體", size=12, color="636e72")
FONT_DATA = Font(name="微軟正黑體", size=11)
FONT_SECTION = Font(name="微軟正黑體", bold=True, size=13, color="d63031")
THIN_BORDER = Border(
    left=Side(style='thin', color='dfe6e9'),
    right=Side(style='thin', color='dfe6e9'),
    top=Side(style='thin', color='dfe6e9'),
    bottom=Side(style='thin', color='dfe6e9'),
)


def fetch_json(url, retries=3):
    ctx = ssl.create_default_context()
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            resp = urllib.request.urlopen(req, timeout=20, context=ctx)
            return json.loads(resp.read())
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2)
                continue
            print(f"  e {e}")
            return None


def fetch_twse_pb():
    """抓證交所 P/B + 殖利率 + 本益比"""
    print(" 正在抓取證交所資料...")
    data = fetch_json("https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL")
    if not data:
        print("e 證交所 API 失敗")
        return [], []

    stocks = []
    for r in data:
        pb_str = (r.get("PBratio", "") or "").strip()
        if not pb_str:
            continue
        try:
            pb = float(pb_str)
        except:
            continue
        dy = (r.get("DividendYield", "") or "").strip()
        pe = (r.get("PEratio", "") or "").strip()
        stocks.append({
            "code": r.get("Code", ""),
            "name": r.get("Name", "").strip(),
            "pb": pb,
            "dy": float(dy) if dy else None,
            "pe": float(pe) if pe else None,
        })

    cigar = [s for s in stocks if s["pb"] < 1.0]
    cigar.sort(key=lambda r: r["pb"])
    print(f" 上市共 {len(stocks)} 檔有 P/B 資料")
    print(f" P/B < 1: {len(cigar)} 檔")
    return cigar, stocks


def fetch_prices(cigar):
    """從證交所抓個股收盤價"""
    print(" 抓取股價...")
    url = "https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"
    data = fetch_json(url)
    price_map = {}
    if data:
        for r in data:
            code = r.get("Code", "")
            try:
                close = float(r.get("ClosingPrice", 0) or 0)
                if close > 0:
                    price_map[code] = close
            except:
                pass
    for s in cigar:
        s["price"] = price_map.get(s["code"])
    have = sum(1 for s in cigar if s["price"])
    print(f" {have}/{len(cigar)} 檔有股價")
    return cigar


def set_cell(ws, row, col, value, font=None, fmt=None, fill=None, align_center=True):
    c = ws.cell(row=row, column=col, value=value)
    if font: c.font = font
    if fmt: c.number_format = fmt
    if fill: c.fill = fill
    if align_center: c.alignment = Alignment(horizontal="center", vertical="center")
    c.border = THIN_BORDER
    return c


def create_excel(cigar, all_stocks):
    print(" 產生 Excel...")
    wb = Workbook()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    decent = [s for s in cigar
              if 0.5 <= s["pb"] <= 0.85
              and s["dy"] is not None and s["dy"] >= 4]
    decent.sort(key=lambda r: r["dy"], reverse=True)

    # ===== Sheet 1: 清單 =====
    ws = wb.active
    ws.title = "清單"
    ws.sheet_properties.tabColor = "d63031"
    widths1 = [8, 14, 8, 10, 11, 11, 18, 20]
    for i, w in enumerate(widths1, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.merge_cells("A1:H1")
    ws["A1"].value = "台股菸屁股篩選 (P/B < 1)"
    ws["A1"].font = FONT_TITLE
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("A2:H2")
    ws["A2"].value = f"資料日期: 2026-07-16 (上市公司) | 產出: {ts}"
    ws["A2"].font = FONT_SUBTITLE
    ws["A2"].alignment = Alignment(horizontal="center")

    ws.merge_cells("A4:H4")
    ws["A4"].value = "條件: P/B < 1.0 (股價低於每股淨值) | 來源: 證交所 BWIBBU_ALL"
    ws["A4"].font = Font(name="微軟正黑體", size=10, color="636e72", italic=True)

    h1 = ["代號", "股票名稱", "市場", "P/B值", "殖利率%", "本益比", "潛力評價", "備註"]
    hr = 6
    for col, h in enumerate(h1, 1):
        set_cell(ws, hr, col, h, font=FONT_HEADER, fill=FILL_HEADER)
    ws.row_dimensions[hr].height = 28

    for idx, s in enumerate(cigar):
        row = hr + 1 + idx
        set_cell(ws, row, 1, s["code"], font=Font(name="微軟正黑體", size=11, bold=True))
        set_cell(ws, row, 2, s["name"], font=FONT_DATA)
        set_cell(ws, row, 3, "上市", font=FONT_DATA)

        pb_font = Font(name="微軟正黑體", size=12, bold=True, color=COLOR_RED if s["pb"] < 0.5 else "2d3436")
        set_cell(ws, row, 4, s["pb"], font=pb_font, fmt="0.00")

        if s["dy"] is not None:
            dy_font = Font(name="微軟正黑體", size=11, color=COLOR_RED if s["dy"] >= 6 else "2d3436")
            set_cell(ws, row, 5, s["dy"]/100, font=dy_font, fmt="0.00%")
        else:
            set_cell(ws, row, 5, "—", font=Font(name="微軟正黑體", size=11, color="b2bec3"))

        if s["pe"] is not None:
            set_cell(ws, row, 6, s["pe"], font=FONT_DATA, fmt="0.0")
        else:
            set_cell(ws, row, 6, "—", font=Font(name="微軟正黑體", size=11, color="b2bec3"))

        has_dy = s["dy"] is not None and s["dy"] >= 4
        if s["pb"] < 0.4 and not has_dy:
            set_cell(ws, row, 7, "價值陷阱風險高", font=Font(name="微軟正黑體", size=10, color="d63031"))
        elif s["pb"] <= 0.85 and has_dy:
            set_cell(ws, row, 7, "有料", font=Font(name="微軟正黑體", size=10, bold=True, color="d63031"))
            ws.cell(row=row, column=1).fill = FILL_RED
        elif s["pb"] <= 0.65:
            set_cell(ws, row, 7, "可觀察", font=Font(name="微軟正黑體", size=10, color="636e72"))
        else:
            set_cell(ws, row, 7, "", font=Font(name="微軟正黑體", size=10, color="b2bec3"))

        notes = []
        if s["dy"] is not None and s["dy"] >= 8: notes.append(f"高殖利率{s['dy']:.1f}%")
        if s["pe"] is not None and 0 < s["pe"] < 10: notes.append(f"低本益比{s['pe']:.1f}")
        if s["pb"] < 0.5: notes.append("嚴重破淨")
        set_cell(ws, row, 8, "、".join(notes) if notes else "", font=Font(name="微軟正黑體", size=10, color="636e72"))

    ws.freeze_panes = f"A{hr + 1}"
    ws.auto_filter.ref = f"A{hr}:H{hr + len(cigar)}"

    # ===== Sheet 2: 有料菸屁股 =====
    ws2 = wb.create_sheet("有料菸屁股")
    ws2.sheet_properties.tabColor = "e17055"
    widths2 = [8, 14, 8, 11, 10, 11, 11, 20]
    for i, w in enumerate(widths2, 1):
        ws2.column_dimensions[get_column_letter(i)].width = w

    ws2.merge_cells("A1:H1")
    ws2["A1"].value = "有料的菸屁股"
    ws2["A1"].font = FONT_TITLE
    ws2["A1"].alignment = Alignment(horizontal="center")
    ws2.row_dimensions[1].height = 35

    ws2.merge_cells("A2:H2")
    ws2["A2"].value = f"P/B 0.5~0.85 + 殖利率 >= 4% | 共 {len(decent)} 檔"
    ws2["A2"].font = FONT_SUBTITLE
    ws2["A2"].alignment = Alignment(horizontal="center")

    h2 = ["代號", "股票名稱", "市場", "收盤價", "P/B值", "殖利率", "本益比", "備註"]
    hr2 = 4
    for col, h in enumerate(h2, 1):
        set_cell(ws2, hr2, col, h, font=FONT_HEADER, fill=FILL_HEADER)

    for idx, s in enumerate(decent):
        row = hr2 + 1 + idx
        set_cell(ws2, row, 1, s["code"], font=Font(name="微軟正黑體", size=11, bold=True))
        set_cell(ws2, row, 2, s["name"], font=FONT_DATA)
        set_cell(ws2, row, 3, "上市", font=FONT_DATA)

        if s.get("price"):
            set_cell(ws2, row, 4, s["price"], font=Font(name="微軟正黑體", size=11, bold=True), fmt="#,##0.00")
        else:
            set_cell(ws2, row, 4, "—", font=Font(name="微軟正黑體", size=11, color="b2bec3"))

        set_cell(ws2, row, 5, s["pb"], font=Font(name="微軟正黑體", size=12, bold=True, color=COLOR_RED), fmt="0.00")
        set_cell(ws2, row, 6, s["dy"]/100, font=Font(name="微軟正黑體", size=11, bold=True, color=COLOR_RED), fmt="0.0%")

        if s["pe"] is not None:
            set_cell(ws2, row, 7, s["pe"], font=FONT_DATA, fmt="0.0")
        else:
            set_cell(ws2, row, 7, "—", font=Font(name="微軟正黑體", size=11, color="b2bec3"))

        pe = s["pe"] or 0
        n2 = []
        if s["dy"] >= 8: n2.append(f"高殖利率{s['dy']:.1f}%")
        if 0 < pe < 10: n2.append("低本益比")
        set_cell(ws2, row, 8, "、".join(n2) if n2 else "",
                 font=Font(name="微軟正黑體", size=10, color="636e72"))

    # ===== Sheet 3: 統計 =====
    ws3 = wb.create_sheet("統計")
    ws3.sheet_properties.tabColor = "0984e3"
    ws3.column_dimensions["A"].width = 30
    ws3.column_dimensions["B"].width = 15

    stats = [
        ("統計摘要", ""),
        ("", ""),
        ("資料日期", "2026-07-16"),
        ("資料來源", "證交所 BWIBBU_ALL + STOCK_DAY_ALL"),
        ("上市有 P/B 資料", len(all_stocks)),
        ("P/B < 1 (菸屁股)", len(cigar)),
        ("有料菸屁股 (P/B 0.5~0.85 + 殖利率>=4%)", len(decent)),
        ("", ""),
        ("P/B 分布", ""),
        ("P/B < 0.3", len([s for s in cigar if s["pb"] < 0.3])),
        ("0.3 <= P/B < 0.5", len([s for s in cigar if 0.3 <= s["pb"] < 0.5])),
        ("0.5 <= P/B < 0.7", len([s for s in cigar if 0.5 <= s["pb"] < 0.7])),
        ("0.7 <= P/B < 0.9", len([s for s in cigar if 0.7 <= s["pb"] < 0.9])),
        ("0.9 <= P/B < 1.0", len([s for s in cigar if 0.9 <= s["pb"] < 1.0])),
    ]

    for row, (k, v) in enumerate(stats, 1):
        cell_a = set_cell(ws3, row, 1, k, font=FONT_SECTION if k.endswith("分布") or k == "統計摘要" else Font(name="微軟正黑體", size=11))
        if k == "":
            continue
        if isinstance(v, int):
            set_cell(ws3, row, 2, v, font=Font(name="微軟正黑體", size=11, bold=True, color=COLOR_RED))

    wb.save(XLSX_PATH)
    print(f" Excel: {XLSX_PATH}")
    return XLSX_PATH


def create_html(cigar, all_stocks):
    """產生獨立 HTML 報告。"""
    print(" 產生 HTML...")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    decent = [s for s in cigar if 0.5 <= s["pb"] <= 0.85 and s["dy"] is not None and s["dy"] >= 4]
    decent.sort(key=lambda r: r["dy"], reverse=True)

    def fmt_num(v, digits=2, default="—"):
        if v is None:
            return default
        return f"{v:.{digits}f}"

    def fmt_pct(v, digits=1, default="—"):
        if v is None:
            return default
        return f"{v:.{digits}f}%"

    pb_bins = [
        ("P/B < 0.3", len([s for s in cigar if s["pb"] < 0.3])),
        ("0.3 <= P/B < 0.5", len([s for s in cigar if 0.3 <= s["pb"] < 0.5])),
        ("0.5 <= P/B < 0.7", len([s for s in cigar if 0.5 <= s["pb"] < 0.7])),
        ("0.7 <= P/B < 0.9", len([s for s in cigar if 0.7 <= s["pb"] < 0.9])),
        ("0.9 <= P/B < 1.0", len([s for s in cigar if 0.9 <= s["pb"] < 1.0])),
    ]

    html_parts = []
    hero_html = """<!doctype html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>台股菸屁股選股報告</title>
  <style>
    :root{{
      --bg:#0f1720;
      --panel:#16202a;
      --panel-2:#1b2733;
      --header:#2d3436;
      --text:#ecf0f1;
      --muted:#b2bec3;
      --line:#314150;
      --red:#d63031;
      --green:#00b894;
      --amber:#fdcb6e;
      --good:#d63031;
      --bad:#00b894;
    }}
    *{{box-sizing:border-box}}
    body{{
      margin:0;
      background:
        radial-gradient(circle at top left, rgba(214,48,49,.16), transparent 24%),
        radial-gradient(circle at top right, rgba(0,184,148,.12), transparent 22%),
        linear-gradient(180deg, #0b1118 0%, #111a23 100%);
      color:var(--text);
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC","Microsoft JhengHei",sans-serif;
      line-height:1.5;
    }}
    .wrap{{max-width:1400px;margin:0 auto;padding:28px 18px 40px}}
    .hero{{
      background:linear-gradient(135deg, rgba(45,52,54,.98), rgba(27,39,51,.98));
      border:1px solid rgba(255,255,255,.07);
      border-radius:24px;
      padding:28px;
      box-shadow:0 18px 50px rgba(0,0,0,.25);
    }}
    .eyebrow{{color:var(--amber);font-size:13px;letter-spacing:.12em;text-transform:uppercase;margin-bottom:8px}}
    h1{{margin:0;font-size:34px;line-height:1.1}}
    .subtitle{{margin-top:10px;color:var(--muted);font-size:14px}}
    .cards{{
      display:grid;
      grid-template-columns:repeat(3,minmax(0,1fr));
      gap:14px;
      margin-top:18px;
    }}
    .card{{
      background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.07);
      border-radius:18px;
      padding:18px;
    }}
    .card .label{{color:var(--muted);font-size:13px;margin-bottom:10px}}
    .card .value{{font-size:30px;font-weight:800}}
    .card .hint{{margin-top:6px;color:var(--muted);font-size:12px}}
    .section{{
      margin-top:22px;
      background:rgba(12,18,24,.78);
      border:1px solid rgba(255,255,255,.06);
      border-radius:22px;
      overflow:hidden;
      box-shadow:0 12px 36px rgba(0,0,0,.2);
    }}
    .section-head{{
      padding:18px 22px;
      background:linear-gradient(90deg, rgba(45,52,54,.95), rgba(27,39,51,.95));
      border-bottom:1px solid rgba(255,255,255,.06);
    }}
    .section-head h2{{margin:0;font-size:20px}}
    .section-head p{{margin:6px 0 0;color:var(--muted);font-size:13px}}
    .table-wrap{{overflow-x:auto}}
    table{{width:100%;border-collapse:collapse;min-width:920px}}
    th,td{{padding:12px 12px;border-bottom:1px solid rgba(255,255,255,.06);vertical-align:middle}}
    th{{
      text-align:left;
      font-size:13px;
      color:#f5f6fa;
      background:rgba(45,52,54,.95);
      position:sticky;
      top:0;
      z-index:1;
    }}
    tbody tr:nth-child(odd){{background:rgba(255,255,255,.03)}}
    tbody tr:nth-child(even){{background:rgba(255,255,255,.015)}}
    tbody tr:hover{{background:rgba(255,255,255,.06)}}
    .num{{text-align:right;font-variant-numeric:tabular-nums}}
    .code{{font-weight:800;color:#fff}}
    .positive{{color:var(--good);font-weight:700}}
    .negative{{color:var(--bad);font-weight:700}}
    .badge{{
      display:inline-block;
      padding:4px 8px;
      border-radius:999px;
      font-size:12px;
      font-weight:700;
      white-space:nowrap;
    }}
    .badge.good{{background:rgba(214,48,49,.12);color:#ff7675;border:1px solid rgba(214,48,49,.28)}}
    .badge.warn{{background:rgba(253,203,110,.12);color:#ffeaa7;border:1px solid rgba(253,203,110,.22)}}
    .badge.bad{{background:rgba(0,184,148,.12);color:#55efc4;border:1px solid rgba(0,184,148,.22)}}
    .note-red{{color:#ff7675}}
    .note-green{{color:#55efc4}}
    .stats-grid{{
      display:grid;
      grid-template-columns:repeat(2,minmax(0,1fr));
      gap:14px;
      padding:18px 22px 22px;
    }}
    .mini{{
      background:rgba(255,255,255,.03);
      border:1px solid rgba(255,255,255,.06);
      border-radius:16px;
      padding:14px;
    }}
    .mini-title{{color:var(--muted);font-size:13px;margin-bottom:8px}}
    .mini-value{{font-size:22px;font-weight:800}}
    .mini-desc{{margin-top:6px;color:var(--muted);font-size:12px}}
    .footer{{color:var(--muted);font-size:12px;padding:20px 4px 0;text-align:right}}
    @media (max-width: 900px){{
      .cards,.stats-grid{{grid-template-columns:1fr}}
      h1{{font-size:28px}}
      table{{min-width:760px}}
      .wrap{{padding:16px 12px 28px}}
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <div class="eyebrow">Taiwan Stock Value Screen</div>
      <h1>台股菸屁股選股報告</h1>
      <div class="subtitle">產生時間：__TS__ | 資料來源：證交所公開 API</div>
      <div class="cards">
        <div class="card">
          <div class="label">總股票數</div>
          <div class="value">__N1__</div>
          <div class="hint">有 P/B 資料的上市股票</div>
        </div>
        <div class="card">
          <div class="label">P/B &lt; 1</div>
          <div class="value">__N2__</div>
          <div class="hint">進入菸屁股候選池</div>
        </div>
        <div class="card">
          <div class="label">有料菸屁股</div>
          <div class="value">__N3__</div>
          <div class="hint">0.5 &lt;= P/B &lt;= 0.85 且 殖利率 &gt;= 4%</div>
        </div>
      </div>
    </div>
""" 
    hero_html = hero_html.replace("\x7b\x7b", "\x7b").replace("\x7d\x7d", "\x7d")
    hero_html = hero_html.replace("__TS__", ts).replace("__N1__", str(len(all_stocks))).replace("__N2__", str(len(cigar))).replace("__N3__", str(len(decent)))
    html_parts.append(hero_html)

    summary_html = """
    <div class="section">
      <div class="section-head">
        <h2>💎 有料菸屁股</h2>
        <p>條件：0.5 &lt;= P/B &lt;= 0.85 且 殖利率 &gt;= 4% ，依殖利率由高到低排序</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>代號</th>
              <th>股票名稱</th>
              <th class="num">收盤價</th>
              <th class="num">P/B值</th>
              <th class="num">殖利率</th>
              <th class="num">本益比</th>
              <th>備註</th>
            </tr>
          </thead>
          <tbody>
"""
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")

    if decent:
        for s in decent:
            notes = []
            if s.get("dy") is not None and s["dy"] >= 8:
                notes.append('<span class="badge good">高殖利率</span>')
            if s.get("pe") is not None and 0 < s["pe"] < 10:
                notes.append('<span class="badge warn">低本益比</span>')
            if s["pb"] <= 0.65:
                notes.append('<span class="badge bad">P/B 甜區</span>')
            html_parts.append(
                "<tr>"
                f"<td class='code'>{escape(s['code'])}</td>"
                f"<td>{escape(s['name'])}</td>"
                f"<td class='num'>{fmt_num(s.get('price'))}</td>"
                f"<td class='num positive'>{fmt_num(s['pb'])}</td>"
                f"<td class='num positive'>{fmt_pct(s.get('dy'))}</td>"
                f"<td class='num'>{fmt_num(s.get('pe'), 1)}</td>"
                f"<td>{' '.join(notes) if notes else '<span class=\"badge warn\">觀察中</span>'}</td>"
                "</tr>"
            )
    else:
        html_parts.append("<tr><td colspan='7' style='text-align:center;color:#b2bec3;padding:24px'>沒有符合條件的股票</td></tr>")

    regular_html = """
          </tbody>
        </table>
      </div>
    </div>
"""
    regular_html = regular_html.replace("{{", "{").replace("}}", "}")

    summary_html = """
    <div class="section">
      <div class="section-head">
        <h2>📊 P/B 分布</h2>
        <p>菸屁股候選池的 P/B 區間統計</p>
      </div>
      <div class="stats-grid">
"""
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")
    for label, count in pb_bins:
        pct = (count / len(cigar) * 100) if cigar else 0
        html_parts.append(
            "<div class='mini'>"
            f"<div class='mini-title'>{escape(label)}</div>"
            f"<div class='mini-value'>{count}</div>"
            f"<div class='mini-desc'>占 P/B &lt; 1 的 {pct:.1f}%</div>"
            "</div>"
        )
    summary_html = """
      </div>
    </div>
"""
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")

    summary_html = """
    <div class="section">
      <div class="section-head">
        <h2>🚬 全部 P/B&lt;1 清單</h2>
        <p>完整菸屁股候選名單，依 P/B 由低到高排序</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>代號</th>
              <th>股票名稱</th>
              <th class="num">P/B值</th>
              <th class="num">殖利率%</th>
              <th class="num">本益比</th>
              <th>潛力評價</th>
              <th>備註</th>
            </tr>
          </thead>
          <tbody>
"""

    def potential_label(s):
        if s["pb"] < 0.4 and (s.get("dy") is None or s["dy"] < 4):
            return '<span class="badge bad">價值陷阱風險</span>'
        if s["pb"] <= 0.85 and s.get("dy") is not None and s["dy"] >= 4:
            return '<span class="badge good">有料</span>'
        if s["pb"] <= 0.65:
            return '<span class="badge warn">可觀察</span>'
        return '<span class="badge warn">持續追蹤</span>'

    for s in cigar:
        notes = []
        if s.get("dy") is not None and s["dy"] >= 8:
            notes.append('<span class="note-red">高殖利率</span>')
        if s.get("pe") is not None and 0 < s["pe"] < 10:
            notes.append('<span class="note-red">低本益比</span>')
        if s["pb"] < 0.5:
            notes.append('<span class="note-green">嚴重破淨</span>')
        if s.get("dy") is not None and s["dy"] < 4:
            notes.append('<span class="note-green">殖利率偏低</span>')
        html_parts.append(
            "<tr>"
            f"<td class='code'>{escape(s['code'])}</td>"
            f"<td>{escape(s['name'])}</td>"
            f"<td class='num positive'>{fmt_num(s['pb'])}</td>"
            f"<td class='num {'positive' if s.get('dy') is not None and s['dy'] >= 4 else 'negative'}'>{fmt_pct(s.get('dy'))}</td>"
            f"<td class='num'>{fmt_num(s.get('pe'), 1)}</td>"
            f"<td>{potential_label(s)}</td>"
            f"<td>{' '.join(notes) if notes else '<span class=\"badge warn\">-</span>'}</td>"
            "</tr>"
        )

    summary_html = """
          </tbody>
        </table>
      </div>
    </div>
"""
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")
    summary_html = summary_html.replace("{{", "{").replace("}}", "}")

    summary_html = """
    <div class="section">
      <div class="section-head">
        <h2>📈 摘要統計</h2>
        <p>快速看整體分布與篩選結果</p>
      </div>
      <div class="table-wrap">
        <table style="min-width:unset">
          <thead>
            <tr>
              <th>項目</th>
              <th class="num">數值</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>總股票數</td><td class="num">%d</td></tr>
            <tr><td>P/B &lt; 1</td><td class="num">%d</td></tr>
            <tr><td>有料菸屁股</td><td class="num">%d</td></tr>
""" % (len(all_stocks), len(cigar), len(decent))
    html_parts.append(regular_html)

    for label, count in pb_bins:
        html_parts.append(f"<tr><td>{escape(label)}</td><td class='num'>{count}</td></tr>")

    html_parts.append("""
          </tbody>
        </table>
      </div>
    </div>
    <div class="footer">台灣慣例：紅色代表上漲/正值，綠色代表下跌/負值</div>
  </div>
</body>
</html>
""")

    html = "".join(html_parts)
    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print(f" HTML: {HTML_PATH}")
    return HTML_PATH


def upload_dropbox(file_path):
    creds_path = os.path.expanduser("~/.openclaw/credentials/dropbox.json")
    if not os.path.exists(creds_path):
        print(" 無 Dropbox 憑證，跳過上傳")
        return None

    with open(creds_path) as f:
        creds = json.load(f)
    ctx = ssl.create_default_context()
    filename = os.path.basename(file_path)
    dropbox_path = f"/小虎歌曲/台股分析/{filename}"

    def do_upload(token):
        with open(file_path, "rb") as f:
            data = f.read()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/octet-stream",
            "Dropbox-API-Arg": json.dumps({"path": dropbox_path, "mode": "overwrite"}),
        }
        req = urllib.request.Request("https://content.dropboxapi.com/2/files/upload", data=data, headers=headers, method="POST")
        return urllib.request.urlopen(req, timeout=30, context=ctx)

    try:
        do_upload(creds["access_token"])
        print(f" Dropbox: {dropbox_path}")
    except urllib.error.HTTPError as e:
        if e.code == 401 and creds.get("refresh_token"):
            print(" Token 過期，自動 refresh...")
            data = urllib.parse.urlencode({
                "grant_type": "refresh_token", "refresh_token": creds["refresh_token"],
                "client_id": "tj7phfpix5220nn", "client_secret": "***",
            }).encode()
            req = urllib.request.Request("https://api.dropboxapi.com/oauth2/token", data=data, method="POST")
            resp = urllib.request.urlopen(req, timeout=15, context=ctx)
            result = json.loads(resp.read())
            creds["access_token"] = result["access_token"]
            if result.get("refresh_token"): creds["refresh_token"] = result["refresh_token"]
            with open(creds_path, "w") as f: json.dump(creds, f, indent=2)
            do_upload(creds["access_token"])
            print(f" Dropbox (refresh): {dropbox_path}")
        else:
            print(f" e Dropbox 失敗: HTTP {e.code}")
            return None

    try:
        headers = {"Authorization": f"Bearer {creds['access_token']}", "Content-Type": "application/json"}
        req = urllib.request.Request(
            "https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings",
            data=json.dumps({"path": dropbox_path, "settings": {"requested_visibility": "public"}}).encode(),
            headers=headers, method="POST",
        )
        resp = urllib.request.urlopen(req, timeout=15, context=ctx)
        link = json.loads(resp.read())["url"].replace("dl=0", "dl=0")
        print(f" {link}")
        return link
    except urllib.error.HTTPError as e:
        if e.code == 409:
            req2 = urllib.request.Request(
                "https://api.dropboxapi.com/2/sharing/list_shared_links",
                data=json.dumps({"path": dropbox_path}).encode(), headers=headers, method="POST",
            )
            links = json.loads(urllib.request.urlopen(req2, timeout=15, context=ctx).read()).get("links", [])
            if links:
                link = links[0]["url"].replace("dl=0", "dl=0")
                print(f" {link}")
                return link
        print(f" e 分享連結失敗: HTTP {e.code}")
        return None


def main():
    print("=" * 50)
    print(" 台股菸屁股選股工具 v1.1")
    print(f" {datetime.now().strftime('%Y-%m-%d %H:%M')} UTC")
    print("=" * 50)

    cigar, all_stocks = fetch_twse_pb()
    if not all_stocks:
        print("e 無法獲取資料")
        sys.exit(1)

    cigar = fetch_prices(cigar)
    create_excel(cigar, all_stocks)
    html_path = create_html(cigar, all_stocks)

    print("\n☁️ 上傳 Dropbox...")
    link = upload_dropbox(XLSX_PATH)

    decent = [s for s in cigar if 0.5 <= s["pb"] <= 0.85 and s["dy"] is not None and s["dy"] >= 4]
    decent.sort(key=lambda r: r["dy"], reverse=True)

    print(f"\n{'='*50}")
    print(f" 完成!")
    print(f" P/B < 1 菸屁股: {len(cigar)} 檔")
    print(f" 有料菸屁股: {len(decent)} 檔")
    print(f" Excel: {XLSX_PATH}")
    if link: print(f" Dropbox: {link}")
    print(f"{'='*50}")

    if decent:
        print(f"\nTOP 5 有料菸屁股:")
        for s in decent[:5]:
            ps = f" 市價{s['price']:.2f}" if s.get("price") else ""
            print(f"  {s['code']} {s['name']} P/B={s['pb']:.2f} 殖利率={s['dy']:.1f}% {ps}")


if __name__ == "__main__":
    main()
