# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
"""
照片整理工具 v2.0 - 小虎 (2026-07-10)

功能：
  把 E:\\照片 整理成 E:\\照片_整理\\年\\繁中城市\\
  + E:\\照片_整理\\年\\無GPS\\  (有日期沒 GPS)
  + E:\\照片_整理\\年\\未知\\   (沒 EXIF，用 mtime)
  + D:\\重複\\                (重複檔)

GPS 反查用 Nominatim (OpenStreetMap) 線上 + 繁體中文
GPS 點去重 + 快取到本地 (減少 API call)

依賴：
  pip install Pillow requests
"""

import os
import sys
import json
import time
import shutil
import hashlib
import re
from pathlib import Path
from collections import defaultdict
from datetime import datetime

try:
    from PIL import Image
    from PIL.ExifTags import TAGS, GPSTAGS
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print('⚠️  沒裝 Pillow，EXIF 抓不到，請先跑: pip install Pillow')

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print('⚠️  沒裝 requests，GPS 反查會失敗，請先跑: pip install requests')

# ========== 常數 ==========
# ====================================================
# ⭐ 路徑設定 (老大改這就好) ⭐
# ====================================================
SOURCE = Path(r'E:\照片')
TARGET = Path(r'E:\照片_整理')
DUPLICATES = Path(r'E:\重複')
CACHE_FILE = Path(r'E:\photo_organizer_cache.json')

# ====================================================
# ⭐ 分段跑設定 (老大改這 2 個就好) ⭐
# ====================================================
SKIP_FILES = 0       # 跳過前 N 個: 第一次 0, 第二次 5000, 第三次 10000...
MAX_FILES = 5000     # 這次最多處理幾個 (5000, 10000 或 0=不限)

# 進度檔 (自動記錄處理到哪, 下次跑會自動跳過已處理過的, 不用手動改 SKIP)
PROGRESS_FILE = Path(r'E:\photo_organizer_progress.json')
PROCESSED_INDEX_FILE = Path(r'E:\photo_organizer_processed.txt')
# ====================================================

# Nominatim 設定
NOMINATIM_URL = 'https://nominatim.openstreetmap.org/reverse'
USER_AGENT = 'xiaohu-photo-organizer/2.0'
ACCEPT_LANG = 'zh-TW'  # 繁體中文
REQUEST_DELAY = 1.1  # Nominatim 規定 1 req/sec，加一點 buffer

# 支援的圖片格式
IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.heic', '.tiff', '.tif', '.webp'}

# 非法檔名字元
ILLEGAL_CHARS = r'[<>:"/\\|?*\x00-\x1f]'


def safe_filename(name: str) -> str:
    return re.sub(ILLEGAL_CHARS, '_', name).strip(' .')[:200]


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ''


def get_exif_data(path: Path) -> dict:
    """抓 EXIF（日期 + GPS）"""
    if not HAS_PIL:
        return {}
    try:
        img = Image.open(path)
        exif_raw = img._getexif()
        if not exif_raw:
            return {}

        exif = {}
        for tag_id, value in exif_raw.items():
            tag = TAGS.get(tag_id, tag_id)
            exif[tag] = value

        # 解析日期
        date = None
        for date_tag in ('DateTimeOriginal', 'DateTimeDigitized', 'DateTime'):
            if date_tag in exif:
                val = str(exif[date_tag])
                try:
                    date = datetime.strptime(val, '%Y:%m:%d %H:%M:%S')
                    break
                except ValueError:
                    pass

        # 解析 GPS
        gps = None
        if 'GPSInfo' in exif:
            gps_info = exif['GPSInfo']
            gps_data = {}
            for key, val in gps_info.items():
                gps_data[GPSTAGS.get(key, key)] = val
            gps = _parse_gps(gps_data)

        return {'date': date, 'gps': gps}
    except Exception:
        return {}


def _parse_gps(gps_data: dict) -> tuple:
    """把 EXIF GPS 格式轉成 (lat, lon)"""
    try:
        def to_decimal(dms, ref):
            d, m, s = [float(x) for x in dms]
            decimal = d + m / 60 + s / 3600
            if ref in ('S', 'W'):
                decimal = -decimal
            return decimal

        lat = to_decimal(gps_data['GPSLatitude'], gps_data['GPSLatitudeRef'])
        lon = to_decimal(gps_data['GPSLongitude'], gps_data['GPSLongitudeRef'])
        return (round(lat, 3), round(lon, 3))  # 3 位小數 ~ 100m
    except Exception:
        return None


def reverse_geocode(lat: float, lon: float, cache: dict) -> str:
    """Nominatim 反查 GPS → 繁中城市名（帶快取）"""
    key = f'{lat},{lon}'
    if key in cache:
        return cache[key]

    if not HAS_REQUESTS:
        return '未連線'

    try:
        resp = requests.get(
            NOMINATIM_URL,
            params={
                'lat': lat,
                'lon': lon,
                'format': 'json',
                'accept-language': ACCEPT_LANG,
                'zoom': 10,  # 城市級
            },
            headers={'User-Agent': USER_AGENT},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            # 優先順序: city > town > county > state
            addr = data.get('address', {})
            city = (addr.get('city')
                    or addr.get('town')
                    or addr.get('county')
                    or addr.get('state')
                    or addr.get('country')
                    or '未知地點')
            cache[key] = city
            time.sleep(REQUEST_DELAY)  # Nominatim 速率限制
            return city
        else:
            print(f'   ⚠️ HTTP {resp.status_code}: {lat},{lon}')
            return '查詢失敗'
    except Exception as e:
        print(f'   ❌ GPS 反查失敗: {e}')
        return '查詢失敗'


def get_year_from_mtime(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).strftime('%Y')
    except Exception:
        return '未知年'


def scan_photos(source: Path) -> list:
    """掃來源資料夾"""
    items = []
    if not source.exists():
        print(f'❌ 來源資料夾不存在: {source}')
        return items

    print(f'🔍 掃描中: {source}')
    if SKIP_FILES > 0:
        print(f'   ⏭️  跳過前 {SKIP_FILES} 個')
    count = 0
    skipped = 0
    for path in source.rglob('*'):
        if path.is_file() and path.suffix.lower() in IMAGE_EXT:
            if SKIP_FILES > 0 and skipped < SKIP_FILES:
                skipped += 1
                continue
            items.append({'path': path, 'size': path.stat().st_size})
            count += 1
            if MAX_FILES > 0 and count >= MAX_FILES:
                print(f'   ⚠️  已達上限 ({MAX_FILES} 個), 跳過剩餘')
                break
    total_msg = (f' (限制 {MAX_FILES}' + (f', 跳過 {SKIP_FILES}' if SKIP_FILES > 0 else '') + ')') if MAX_FILES > 0 else ''
    print(f'   找到 {len(items)} 張照片' + total_msg)
    return items


def plan_organization(items: list, cache: dict) -> dict:
    """規劃整理計畫"""
    plan = {
        'to_classify': [],   # 年/城市
        'to_no_gps': [],     # 年/無GPS
        'to_unknown': [],    # 年/未知
        'to_duplicate': [],  # D:\重複\
        'duplicates': 0,
        'years': defaultdict(lambda: defaultdict(int)),  # year -> {city: count}
        'unique_gps_points': 0,
    }

    # 算 hash 找重複
    hash_map = defaultdict(list)
    for item in items:
        h = file_hash(item['path'])
        item['hash'] = h
        hash_map[h].append(item)

    seen_hash = set()
    processed = 0
    total = len(items)

    for item in items:
        h = item['hash']
        if h in seen_hash:
            continue
        seen_hash.add(h)

        same_hash = hash_map[h]
        if len(same_hash) > 1:
            first = same_hash[0]
            plan = _classify_photo(first, cache, plan)
            for dup in same_hash[1:]:
                plan['to_duplicate'].append(dup)
                plan['duplicates'] += 1
        else:
            plan = _classify_photo(item, cache, plan)

        processed += 1
        if processed % 50 == 0:
            print(f'   處理中... {processed}/{total}')

    plan['unique_gps_points'] = len(cache)
    return plan


def _classify_photo(item: dict, cache: dict, plan: dict) -> dict:
    """判斷照片該進哪"""
    exif = get_exif_data(item['path'])
    date = exif.get('date')
    gps = exif.get('gps')

    if date:
        year = date.strftime('%Y')
        if gps:
            city = safe_filename(reverse_geocode(gps[0], gps[1], cache))
            item['target_year'] = year
            item['target_city'] = city
            plan['to_classify'].append(item)
            plan['years'][year][city] += 1
        else:
            item['target_year'] = year
            plan['to_no_gps'].append(item)
            plan['years'][year]['無GPS'] += 1
    else:
        # 沒 EXIF，用檔案 mtime
        year = get_year_from_mtime(item['path'])
        item['target_year'] = year
        plan['to_unknown'].append(item)
        plan['years'][year]['未知'] += 1

    return plan


def print_plan(plan: dict, items: list) -> None:
    print('\n' + '=' * 70)
    print('📋 整理計畫預覽')
    print('=' * 70)
    print(f'總共掃到:    {len(items)} 張照片')
    print(f'  分類:       {len(plan["to_classify"])} 張 →  年\\繁中城市\\')
    print(f'  無 GPS:     {len(plan["to_no_gps"])} 張 →  年\\無GPS\\')
    print(f'  未知:       {len(plan["to_unknown"])} 張 →  年\\未知\\')
    print(f'  重複:       {plan["duplicates"]} 張 →  D:\\重複\\')
    print(f'  不重複 GPS 點: {plan["unique_gps_points"]} 個（用於快取）')

    print('\n📂 年份分布:')
    for year in sorted(plan['years'].keys()):
        cities = plan['years'][year]
        print(f'   {year}: {sum(cities.values())} 張')
        for city, cnt in sorted(cities.items(), key=lambda x: -x[1])[:5]:
            print(f'      - {city}: {cnt}')

    print('\n' + '=' * 70)


def execute_plan(plan: dict) -> None:
    print('\n📂 實際搬檔中...')
    TARGET.mkdir(parents=True, exist_ok=True)
    DUPLICATES.mkdir(parents=True, exist_ok=True)

    # 1. 分類: 年/城市
    for item in plan['to_classify']:
        year = item['target_year']
        city = item['target_city']
        target_dir = TARGET / year / city
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / item['path'].name
        _safe_copy(item['path'], target_path)

    # 2. 無 GPS: 年/無GPS
    for item in plan['to_no_gps']:
        year = item['target_year']
        target_dir = TARGET / year / '無GPS'
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / item['path'].name
        _safe_copy(item['path'], target_path)

    # 3. 未知: 年/未知
    for item in plan['to_unknown']:
        year = item['target_year']
        target_dir = TARGET / year / '未知'
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / item['path'].name
        _safe_copy(item['path'], target_path)

    # 4. 重複: D:\重複\
    for item in plan['to_duplicate']:
        try:
            rel = item['path'].relative_to(SOURCE)
        except ValueError:
            rel = Path(item['path'].name)
        sub_dir = DUPLICATES / '照片' / rel.parent
        sub_dir.mkdir(parents=True, exist_ok=True)
        target_path = sub_dir / item['path'].name
        _safe_copy(item['path'], target_path)

    print('✅ 全部完成！')


def _safe_copy(src: Path, dst: Path):
    """複製檔案，處理同檔名"""
    if not dst.exists():
        shutil.copy2(src, dst)
        return
    # 同檔名比 hash
    if file_hash(src) == file_hash(dst):
        return  # 完全重複就跳過
    counter = 1
    while dst.exists():
        dst = dst.with_name(f'{dst.stem}_{counter}{dst.suffix}')
        counter += 1
    shutil.copy2(src, dst)


def load_cache() -> dict:
    if CACHE_FILE.exists():
        try:
            return json.load(open(CACHE_FILE, 'r', encoding='utf-8'))
        except Exception:
            return {}
    return {}


def save_cache(cache: dict):
    try:
        json.dump(cache, open(CACHE_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print(f'💾 快取已存: {CACHE_FILE} ({len(cache)} 個 GPS 點)')
    except Exception as e:
        print(f'⚠️  存快取失敗: {e}')


def main():
    print('=' * 70)
    print('🐯 照片整理工具 v2.2 (支援分段跑)')
    print('=' * 70)
    if SKIP_FILES > 0 or MAX_FILES > 0 or PROCESSED_INDEX_FILE.exists():
        print(f'⚙️  本次: SKIP_FILES={SKIP_FILES}, MAX_FILES={MAX_FILES}')
        if PROCESSED_INDEX_FILE.exists():
            with open(PROCESSED_INDEX_FILE) as f:
                cnt = sum(1 for _ in f)
            print(f'   📋 進度檔: 已處理 {cnt} 個 (下次自動跳過)')
        if MAX_FILES > 0:
            print(f'   💡 下次可直接按 Enter 用預設 {SKIP_FILES + MAX_FILES}')

    if not HAS_PIL:
        print('\n❌ 缺 Pillow，請先裝:')
        print('   pip install Pillow')
        return

    if not SOURCE.exists():
        print(f'\n❌ 來源資料夾不存在: {SOURCE}')
        return

    items = scan_photos(SOURCE)
    if not items:
        print('\n❌ 沒掃到任何照片')
        return

    # 載入 GPS 快取
    cache = load_cache()
    if cache:
        print(f'💾 已載入 {len(cache)} 個 GPS 點快取')

    plan = plan_organization(items, cache)
    print_plan(plan, items)

    print('\n⚠️  即將實際搬檔到 D:\\照片_整理\\')
    print('   來源 D:\\照片 不會被刪除')
    answer = input('\n確認執行嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('\n🚫 已取消，沒動到任何檔案')
        # 還是存快取（下次跑省時間）
        save_cache(cache)
        return

    execute_plan(plan)
    save_cache(cache)


if __name__ == '__main__':
    main()
    print()
    print('=' * 70)
    print('  跑完了！按 Enter 關閉視窗...')
    print('=' * 70)
    input()