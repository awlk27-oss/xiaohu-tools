@echo off
rem Switch to UTF-8 for Chinese output
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Photo Organizer Tool v2.0 (xiaohu 2026-07-10)
echo ============================================================
echo.

rem Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

rem Check Pillow + requests
python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing Pillow + requests...
    pip install Pillow requests
    if errorlevel 1 (
        echo [ERROR] Install failed. Try: pip install Pillow requests
        pause
        exit /b 1
    )
)

echo.
python photo_organizer_v2.py

echo.
pause