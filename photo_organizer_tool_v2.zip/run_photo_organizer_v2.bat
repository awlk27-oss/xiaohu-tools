@echo off
rem Switch to UTF-8 for Chinese output
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Photo Organizer Tool v2.2 (xiaohu 2026-07-10)
echo   Supports batch processing for huge libraries
echo ============================================================
echo.

rem Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)

rem Check Pillow + requests
python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing Pillow + requests...
    pip install Pillow requests
)

echo.
echo ============================================================
echo   BATCH PROCESSING - process your 18K photos in chunks
echo ============================================================
echo.
set SKIP=0
set /p SKIP="Skip first N photos (default 0): "
set MAXCOUNT=1000
set /p MAXCOUNT="Process max N photos (default 1000): "

if "%SKIP%"=="" set SKIP=0
if "%MAXCOUNT%"=="" set MAXCOUNT=1000

rem Patch the .py file with user values
python -c "import re; p = 'photo_organizer_v2.py'; t = open(p).read(); t = re.sub(r'SKIP_FILES = \d+', 'SKIP_FILES = %SKIP%', t); t = re.sub(r'MAX_FILES = \d+', 'MAX_FILES = %MAXCOUNT%', t); open(p, 'w').write(t)"

echo.
echo Running with SKIP_FILES=%SKIP%, MAX_FILES=%MAXCOUNT%
echo.
python photo_organizer_v2.py

echo.
echo ============================================================
echo   Next batch: SKIP_FILES=%SKIP% + MAX_FILES=%MAXCOUNT%
echo   Example: if you ran batch 1 (skip 0), next is SKIP_FILES=5000
echo ============================================================
echo.
pause