@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Photo Organizer Tool v2.3 (xiaohu 2026-07-10)
echo   Batch processing with auto-resume progress
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)

python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing...
    pip install Pillow requests
)

echo.
echo Progress file: E:\photo_organizer_processed.txt
if exist E:\photo_organizer_processed.txt (
    for /f %%N in ('type "E:\photo_organizer_processed.txt" ^| find /c /v ""') do set PROCESSED=%%N
    echo Already processed: !PROCESSED! photos
) else (
    set PROCESSED=0
)
echo.

set SKIP=0
set /p SKIP="Skip first N photos [default 0, suggestion for 2nd batch = 5000 if MAX was 5000]: "
set MAXCOUNT=5000
set /p MAXCOUNT="Process max N photos per run [default 5000]: "

if "%SKIP%"=="" set SKIP=0
if "%MAXCOUNT%"=="" set MAXCOUNT=5000

rem Patch the .py
python -c "import re; p = 'photo_organizer_v2.py'; t = open(p).read(); t = re.sub(r'SKIP_FILES = \d+', 'SKIP_FILES = %SKIP%', t); t = re.sub(r'MAX_FILES = \d+', 'MAX_FILES = %MAXCOUNT%', t); open(p, 'w').write(t)"

echo.
echo Running SKIP_FILES=%SKIP% + MAX_FILES=%MAXCOUNT%
echo.

python photo_organizer_v2.py

echo.
echo ============================================================
echo Next batch suggestion:
echo   SKIP_FILES = %SKIP% (+already processed)
echo   MAX_FILES = %MAXCOUNT%
echo Just keep running same .bat, progress auto-resumes.
echo ============================================================
echo.
pause