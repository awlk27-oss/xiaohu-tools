@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Photo Organizer v2.5 - Direct Python Run
echo ============================================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)
python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing Pillow + requests...
    pip install Pillow requests
)
echo Starting photo_organizer_v2.py ...
echo.
python photo_organizer_v2.py
echo.
pause