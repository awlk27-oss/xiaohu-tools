@echo off
chcp 65001 > nul
cd /d %~dp0
echo ============================================================
echo   照片整理工具 v2.0 (小虎 2026-07-10)
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 找不到 Python
    pause
    exit /b 1
)

python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  缺套件，正在自動安裝...
    pip install Pillow requests
)

echo.
python photo_organizer_v2.py

echo.
pause