@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Photo Organizer Tool v2.4 (xiaohu 2026-07-10)
echo   Batch processing with auto-resume progress (UTF-8)
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)

python -c "import PIL, requests" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing...
    pip install Pillow requests
)

echo.
echo Progress file: E:\photo_organizer_processed.txt
if exist E:\photo_organizer_processed.txt (
    for /f %%N in ('type "E:\photo_organizer_processed.txt" ^| find /c /v ""') do set PROCESSED=%%N
    echo Already processed: !PROCESSED! photos
) else (
    set PROCESSED=0
)
echo.

set SKIP=0
set /p SKIP="Skip first N photos [press Enter for 0]: "
set MAXCOUNT=5000
set /p MAXCOUNT="Process max N photos per run [press Enter for 5000]: "

if "%SKIP%"=="" set SKIP=0
if "%MAXCOUNT%"=="" set MAXCOUNT=5000

rem Generate the patcher Python script
echo import re > _patcher.py
echo p = 'photo_organizer_v2.py' >> _patcher.py
echo t = open(p, 'r', encoding='utf-8').read() >> _patcher.py
echo t = re.sub(r'SKIP_FILES = \d+', 'SKIP_FILES = %SKIP%', t) >> _patcher.py
echo t = re.sub(r'MAX_FILES = \d+', 'MAX_FILES = %MAXCOUNT%', t) >> _patcher.py
echo open(p, 'w', encoding='utf-8').write(t) >> _patcher.py

python _patcher.py
del _patcher.py

echo.
echo Running SKIP_FILES=%SKIP% + MAX_FILES=%MAXCOUNT%
echo.

python photo_organizer_v2.py

echo.
echo ============================================================
echo Next batch suggestion (just re-run this bat):
echo   Already processed: E:\photo_organizer_processed.txt
echo   Will auto-skip on next run, no need to remember SKIP!
echo ============================================================
echo.
pause