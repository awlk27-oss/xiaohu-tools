# 📷 照片整理工具 v2.0

**作者：** 小虎 🐯  
**日期：** 2026-07-10

## 跟 v1 差異
- ❌ 拿掉月份細分（改成以年為主）
- ✅ 改用線上 Nominatim 反查 GPS
- ✅ 城市名稱**繁體中文**
- ✅ GPS 點去重 + 快取（省 API call）

## 使用

### 1. 裝套件
```bash
pip install Pillow requests
```

### 2. 雙擊啟動
點 `run_photo_organizer_v2.bat`

## 結構

```
D:\照片  (來源)
  ├── IMG_001.jpg    (有 EXIF 日期 + GPS 在鹿港)
  ├── IMG_002.jpg    (有 EXIF 在東京)
  ├── IMG_003.jpg    (有日期 無 GPS)
  ├── photo.heic     (沒 EXIF, 2024 年拍)
  └── ...

↓ 整理後 ↓

D:\照片_整理\
  ├── 2023\
  │   ├── 鹿港鎮\           ← 繁中
  │   │   ├── IMG_001.jpg
  │   │   └── ...
  │   ├── 東京\             ← 繁中
  │   │   └── IMG_002.jpg
  │   └── 無GPS\
  │       └── IMG_003.jpg
  └── 2024\
      └── 未知\
          └── photo.heic

D:\重複\
  └── 照片\
      └── 原路徑\
          └── 重複檔.jpg

D:\photo_organizer_cache.json   ← GPS 快取 (下次跑會省 API)
```

## 重要
- **來源 D:\照片 不會被刪除**
- **2 階段**：預覽 → 確認才搬
- **GPS 快取**：自動存到 `D:\photo_organizer_cache.json`，下次跑會自動載入（避免重複 API 查詢）
- **速率**：Nominatim 1 req/sec，5000 張約 5-10 分鐘（如果有很多新 GPS 點）

## 改路徑
編輯 `photo_organizer_v2.py` 常數區：
```python
SOURCE = Path(r'D:\照片')
TARGET = Path(r'D:\照片_整理')
DUPLICATES = Path(r'D:\重複')
CACHE_FILE = Path(r'D:\photo_organizer_cache.json')
```