# -*- coding: utf-8 -*-
"""
照片整理 復原工具 (Undo Organizer)
- 從 UNDO_LOG_DB 讀搬檔紀錄
- 提供「完全復原」/「指定某次 run 復原」/「列出紀錄」
"""

import sqlite3
import shutil
from pathlib import Path
from datetime import datetime

UNDO_LOG_DB = Path(r'E:\photo_organizer_log.db')


def list_runs():
    """列出所有搬檔 run (含檔案數量)"""
    if not UNDO_LOG_DB.exists():
        print('❌ 找不到 log 檔:', UNDO_LOG_DB)
        print('   代表您還沒跑過 photo_organizer_v2, 自然沒紀錄可復原')
        return

    conn = sqlite3.connect(str(UNDO_LOG_DB))
    c = conn.cursor()
    c.execute('''SELECT run_id, COUNT(*) as cnt, MIN(copied_at) as first_at
                 FROM moves WHERE restored = 0
                 GROUP BY run_id ORDER BY first_at DESC''')
    print('=' * 70)
    print('📋 復原清單 (尚未復原的)')
    print('=' * 70)
    print(f"{'Run ID':<20} {'檔案數':>6}  {'首次時間':<19}")
    print('-' * 70)
    runs = c.fetchall()
    for run_id, cnt, first_at in runs:
        print(f'{run_id:<20} {cnt:>6}  {first_at:<19}')
    if not runs:
        print('(沒有未復原的記錄)')
    conn.close()
    return runs


def undo_run(run_id):
    """復原一次 run 的所有搬檔"""
    if not UNDO_LOG_DB.exists():
        print('❌ 找不到 log 檔')
        return

    conn = sqlite3.connect(str(UNDO_LOG_DB))
    c = conn.cursor()
    c.execute('SELECT src_path, dst_path FROM moves WHERE run_id = ? AND restored = 0',
              (run_id,))
    rows = c.fetchall()
    if not rows:
        print(f'❌ 沒有 {run_id} 這個 run, 或已經全部復原')
        conn.close()
        return

    print(f'📦 {run_id} 共 {len(rows)} 個檔案要復原')
    print('-' * 70)
    print('🔍 先預覽 (不刪除任何檔案):')
    print('-' * 70)
    for src, dst in rows[:10]:
        print(f'  {dst}')
        print(f'    → {src}')
    if len(rows) > 10:
        print(f'  ... 還有 {len(rows) - 10} 個')

    print()
    print(f'⚠️  此操作會:')
    print(f'   1. 把 D:\\照片\\ALL\\底下 {len(rows)} 個檔案複製一份回到原來源路徑')
    print(f'   2. ⚠️ 不會刪除 D:\\照片\\ALL\\下的檔案 (您之後可以手動刪)')
    print(f'   3. log 標為 restored = 1')
    print()
    answer = input('確認復原嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('🚫 取消復原')
        conn.close()
        return

    restored = 0
    skipped = 0
    for src, dst in rows:
        src_p = Path(src)
        dst_p = Path(dst)
        if not dst_p.exists():
            print(f'  ⚠️  目標檔不存在: {dst_p}')
            skipped += 1
            continue
        # 複製回去 (不刪除 target, 不覆蓋 source)
        if src_p.exists():
            # 來源已存在, 跳過
            print(f'  ⏭️  來源已存在, 跳過: {src_p.name}')
            skipped += 1
            continue
        # 建立 source 父目錄
        src_p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(dst_p), str(src_p))
        restored += 1

    # 標記為已復原
    c.execute('UPDATE moves SET restored = 1 WHERE run_id = ?', (run_id,))
    conn.commit()
    conn.close()

    print()
    print(f'✅ 復原完成: {restored} 個檔, {skipped} 個跳過')
    print(f'💡 您可以手動刪除 D:\\照片\\ALL\\ 下的檔案 (如果不再需要整理結果)')


def undo_all():
    """復原所有 (從第一個 run 到最後)"""
    runs = list_runs()
    if not runs:
        return

    print()
    answer = input(f'⚠️  將復原所有 {len(runs)} 個 run, 確認嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('🚫 取消')
        return

    for run_id, cnt, _ in runs:
        print(f'\n--- 復原 {run_id} ({cnt} 個檔) ---')
        undo_run(run_id)


def main():
    print('🐯 照片整理 復原工具 v1.0')
    print('=' * 70)
    print()
    print('請選擇:')
    print('  1. 列出所有可復原的 run')
    print('  2. 復原「某次」run')
    print('  3. 復原「所有」')
    print()
    choice = input('選擇 [1/2/3]: ').strip()
    print()

    if choice == '1':
        list_runs()
    elif choice == '2':
        runs = list_runs()
        if not runs:
            return
        run_id = input('\n輸入要復原的 Run ID: ').strip()
        undo_run(run_id)
    elif choice == '3':
        undo_all()
    else:
        print('❌ 無效選擇')


if __name__ == '__main__':
    main()
    print()
    input('按 Enter 關閉視窗...')