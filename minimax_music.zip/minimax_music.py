#!/usr/bin/env python3
"""
MiniMax 音樂生成器
直接 call MiniMax Music API，走老大 Pay as You Go 的 $5

用法：
  # 第一次使用先設定 API Key
  python minimax_music.py

  # 然後選擇功能
"""

import json, ssl, urllib.request, os, sys, time
from datetime import datetime

CONFIG_PATH = os.path.expanduser("~/.openclaw/credentials/minimax.json")
API_BASE = "https://api.minimax.io"
PRICE_PER_SONG = 0.15


def load_key():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f).get("api_key", "")
        except: pass
    return ""


def save_key(api_key):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump({"api_key": api_key}, f, indent=2)
    os.chmod(CONFIG_PATH, 0o600)
    print("  API Key 已儲存！")


def call_api(endpoint, payload, timeout=180):
    api_key = load_key()
    if not api_key:
        print("  請先設定 API Key！")
        return None
    ctx = ssl.create_default_context()
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "xiaohu-music/1.0",
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  HTTP {e.code}: {body[:300]}")
        return None
    except Exception as e:
        print(f"  錯誤: {e}")
        return None


def query_task(endpoint, timeout=30):
    api_key = load_key()
    if not api_key: return None
    ctx = ssl.create_default_context()
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "xiaohu-music/1.0",
    }
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except Exception as e:
        print(f"  查詢錯誤: {e}")
        return None


def wait_task(task_id, max_wait=300, interval=15):
    print(f"  生成中", end="", flush=True)
    for _ in range(max_wait // interval):
        time.sleep(interval)
        result = query_task(f"/v1/music/result/{task_id}")
        if result:
            status = result.get("status", "")
            print(".", end="", flush=True)
            if status in ("Success", "success"):
                print(" ✅")
                return result
            elif status in ("Failed", "fail", "error"):
                print(" ❌")
                print(f"  失敗: {result.get('message', result.get('msg', ''))}")
                return None
        else:
            print("?", end="", flush=True)
    print(" ⏰ 逾時")
    return None


def generate_music(prompt, lyrics=None):
    print(f"\n🎵  正在生成音樂...")
    print(f"   提示詞: {prompt}")
    if lyrics: print(f"   歌詞: {lyrics[:80]}...")
    print(f"   費用: ${PRICE_PER_SONG:.2f}")

    payload = {"model": "music-01", "prompt": prompt}
    if lyrics:
        payload["lyrics"] = lyrics
        payload["lyrics_type"] = "user"

    result = call_api("/v1/music/generate", payload)
    if not result: return

    task_id = result.get("task_id")
    if task_id:
        print(f"   任務ID: {task_id}")
        final = wait_task(task_id)
        if final:
            audio_url = final.get("audio_url") or ""
            if not audio_url:
                data = final.get("data", [])
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict):
                            audio_url = item.get("audio_url") or item.get("url", "")
                            if audio_url: break
            if audio_url:
                print(f"\n  🔗 音檔連結: {audio_url}")
                print(f"  可以複製到瀏覽器收聽或下載")
            else:
                print(f"\n  完整回應:")
                print(json.dumps(final, indent=2, ensure_ascii=False)[:1000])
        return

    audio_url = result.get("audio_url") or result.get("url", "")
    if audio_url:
        print(f"\n  🔗 音檔連結: {audio_url}")
    else:
        print(f"\n  完整回應:")
        print(json.dumps(result, indent=2, ensure_ascii=False)[:1000])


def main():
    print("=" * 50)
    print("  🎵 MiniMax 音樂生成器")
    print("  走 Pay as You Go ($0.15/首)")
    print(f"  日期: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 50)

    # 檢查 API Key
    api_key = load_key()
    if not api_key:
        print("\n  第一次使用，請輸入你的 MiniMax API Key")
        print("  到 https://platform.minimax.io 登入後複製")
        key = input("\n  API Key > ").strip()
        if key:
            save_key(key)
        else:
            print("  未輸入 Key，結束")
            return

    while True:
        print("\n" + "─" * 50)
        print("  1️⃣  輸入提示詞生成音樂")
        print("  2️⃣  輸入提示詞 + 歌詞生成音樂")
        print("  3️⃣  查看風格參考")
        print("  0️⃣  離開")
        print("─" * 50)
        choice = input("\n  請選擇 > ").strip()

        if choice == "0":
            print("  掰掰！")
            break

        elif choice == "1":
            prompt = input("  提示詞（例如：輕快的鋼琴曲）> ").strip()
            if prompt:
                generate_music(prompt)
            else:
                print("  提示詞不能空白")

        elif choice == "2":
            prompt = input("  提示詞（例如：熱血搖滾）> ").strip()
            if not prompt: 
                print("  提示詞不能空白")
                continue
            lyrics = input("  歌詞（可留空純音樂）> ").strip()
            generate_music(prompt, lyrics if lyrics else None)

        elif choice == "3":
            print("\n  🎼 風格參考")
            print("  " + "─" * 40)
            styles = [
                "流行 / Pop", "搖滾 / Rock", "電子 / Electronic",
                "古典 / Classical", "爵士 / Jazz", "民謠 / Folk",
                "嘻哈 / Hip-Hop", "R&B", "重金屬 / Metal",
                "放克 / Funk", "藍調 / Blues", "鄉村 / Country",
                "雷鬼 / Reggae", "電影配樂 / Cinematic",
                "遊戲配樂 / Gaming", "中國風 / Chinese",
                "日式 / Japanese", "搖籃曲 / Lullaby",
                "環境音樂 / Ambient", "Lo-fi",
            ]
            for s in styles:
                print(f"    {s}")

        else:
            print("  無效選項")


if __name__ == "__main__":
    main()
