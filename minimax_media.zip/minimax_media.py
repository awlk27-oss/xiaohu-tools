#!/usr/bin/env python3
"""
MiniMax 媒體生成器 — 音樂 + 圖片 + 影片
直接 call MiniMax API，走老大 Pay as You Go 的 $5

用法：
  python minimax_media.py
"""

import json, ssl, urllib.request, os, sys, time
from datetime import datetime

CONFIG_PATH = os.path.expanduser("~/.openclaw/credentials/minimax.json")
API_BASE = "https://api.minimax.io"

PRICES = {
    "music": {"price": 0.15, "unit": "首"},
    "image": {"price": 0.0035, "unit": "張"},
    "video_768_6s": {"price": 0.28, "unit": "部"},
    "video_768_10s": {"price": 0.56, "unit": "部"},
    "video_1080_6s": {"price": 0.49, "unit": "部"},
}


def load_key():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f).get("api_key", "")
        except: pass
    return ""


def save_key(api_key):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump({"api_key": api_key}, f, indent=2)
    print("  API Key 已儲存！")


def call_api(endpoint, payload, timeout=180):
    api_key = load_key()
    if not api_key:
        print("  請先設定 API Key！")
        return None
    ctx = ssl.create_default_context()
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  HTTP {e.code}: {body[:400]}")
        return None
    except Exception as e:
        print(f"  錯誤: {e}")
        return None


def get_api(endpoint, timeout=30):
    api_key = load_key()
    if not api_key: return None
    ctx = ssl.create_default_context()
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    req = urllib.request.Request(f"{API_BASE}{endpoint}", headers=headers, method="GET")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return json.loads(resp.read())
    except Exception as e:
        print(f"  查詢錯誤: {e}")
        return None


def wait_task(endpoint, task_id, max_wait=300, interval=10):
    print(f"  處理中", end="", flush=True)
    for _ in range(max_wait // interval):
        time.sleep(interval)
        result = get_api(f"{endpoint}/{task_id}")
        if result:
            status = result.get("status", "")
            print(".", end="", flush=True)
            if status in ("Success", "success"):
                print(" ✅")
                return result
            elif status in ("Failed", "fail", "error"):
                print(" ❌")
                msg = result.get("message", result.get("msg", ""))
                print(f"  失敗: {msg}")
                return None
        else:
            print("?", end="", flush=True)
    print(" ⏰ 逾時")
    return None


def gen_music(prompt, lyrics=None):
    print(f"\n🎵  生成音樂 ($0.15)")
    print(f"   提示詞: {prompt}")
    if lyrics: print(f"   歌詞: {lyrics[:60]}...")

    payload = {"model": "music-01", "prompt": prompt}
    if lyrics:
        payload["lyrics"] = lyrics
        payload["lyrics_type"] = "user"

    result = call_api("/v1/music/generate", payload, timeout=180)
    if not result: return

    task_id = result.get("task_id")
    if task_id:
        final = wait_task("/v1/music/result", task_id, max_wait=300, interval=15)
        if final:
            url = final.get("audio_url") or ""
            if not url and final.get("data"):
                for d in final["data"] if isinstance(final["data"], list) else []:
                    if isinstance(d, dict): url = d.get("audio_url") or d.get("url", ""); break
            if url:
                fname = f"minimax_music_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
                print(f"\n  ⏳ 下載 {fname}...", end="", flush=True)
                if download_file(url, fname): print(f" ✅ {fname}")
                else: print(f"\n  🔗 {url}")
            else: print(f"\n  結果: {json.dumps(final, ensure_ascii=False)[:600]}")
        return

    audio = result.get("audio_url") or result.get("url", "")
    if audio:
        fname = f"minimax_music_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
        print(f"\n  ⏳ 下載 {fname}...", end="", flush=True)
        if download_file(audio, fname): print(f" ✅ {fname}")
        else: print(f"\n  🔗 {audio}")
    else: print(json.dumps(result, ensure_ascii=False)[:600])


def download_file(url, filename):
    """下載檔案到同目錄"""
    ctx = ssl.create_default_context()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=30, context=ctx)
        with open(filename, "wb") as f:
            f.write(resp.read())
        return True
    except Exception as e:
        print(f"  下載失敗: {e}")
        return False


def gen_image(prompt, aspect_ratio="1:1", n=1):
    total = 0.0035 * n
    print(f"\n🖼️  生成圖片 (${total:.4f})")
    print(f"   提示詞: {prompt}")

    payload = {
        "model": "image-01", "prompt": prompt,
        "aspect_ratio": aspect_ratio, "n": min(n, 9),
        "response_format": "url", "prompt_optimizer": True,
    }
    result = call_api("/v1/image_generation", payload, timeout=60)
    if not result: return

    urls = []
    # 從 data.image_urls 取
    data = result.get("data", {})
    if isinstance(data, dict) and data.get("image_urls"):
        urls = data["image_urls"]
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("url"):
                urls.append(item["url"])
    if not urls and result.get("image_url"):
        urls.append(result["image_url"])

    if urls:
        print(f"  ✅ {len(urls)} 張")
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        for i, u in enumerate(urls):
            ext = ".jpg"
            fname = f"minimax_image_{ts}_{i+1}{ext}"
            print(f"  ⏳ 下載 {fname}...", end="", flush=True)
            if download_file(u, fname):
                print(f" ✅ {fname}")
            else:
                print(f"\n  🔗 {u}")
    else:
        print(json.dumps(result, ensure_ascii=False)[:600])


def gen_video(prompt, duration=6, resolution="768P"):
    key = f"video_{resolution.lower()}_{duration}s"
    price = PRICES.get(key, {}).get("price", 0.28) if duration <= 6 else 0.56
    print(f"\n🎬  生成影片 (${price:.2f})")
    print(f"   提示詞: {prompt}")

    model = "MiniMax-Hailuo-2.3-Fast" if resolution == "1080P" else "MiniMax-Hailuo-2.3"
    payload = {
        "model": model, "prompt": prompt,
        "duration": min(duration, 10), "resolution": resolution,
    }
    result = call_api("/v1/video_generation", payload, timeout=30)
    if not result: return

    task_id = result.get("task_id")
    if task_id:
        final = wait_task("/v1/video_generation/result", task_id, max_wait=300)
        if final:
            data = final.get("data", [])
            if isinstance(data, list):
                for d in data:
                    if isinstance(d, dict) and d.get("url"):
                        fname = f"minimax_video_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
                        download_file(d['url'], fname)
                        return
            print(json.dumps(final, ensure_ascii=False)[:600])
        return

    data = result.get("data", [])
    if isinstance(data, list):
        for d in data:
            if isinstance(d, dict) and d.get("url"):
                fname = f"minimax_video_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
                download_file(d['url'], fname)
                return
    print(json.dumps(result, ensure_ascii=False)[:600])


def main():
    print("=" * 55)
    print("  🎵🖼️🎬  MiniMax 媒體生成器")
    print("  音樂 $0.15 | 圖片 $0.0035 | 影片 $0.28~$0.56")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 55)

    api_key = load_key()
    if not api_key:
        print()
        print("  第一次使用，請輸入你的 MiniMax API Key")
        print()
        print("  🔑 去哪找 API Key？")
        print("  1. 打開 https://platform.minimax.io")
        print("  2. 登入你的帳號")
        print("  3. 左邊選單 → API Keys")
        print("  4. 複製你的 API Key")
        print("  5. 貼到下面")
        print()
        key = input("  API Key > ").strip()
        if key:
            save_key(key)
        else:
            print("  未輸入，結束")
            return

    while True:
        print()
        print("─" * 50)
        print("  1️⃣  音樂生成")
        print("  2️⃣  圖片生成")
        print("  3️⃣  影片生成")
        print("  4️⃣  更換 API Key")
        print("  0️⃣  離開")
        print("─" * 50)
        choice = input("  請選擇 > ").strip()

        if choice == "0":
            print("  掰掰！")
            break

        elif choice == "1":
            prompt = input("  提示詞（例如：輕快的鋼琴曲）> ").strip()
            if not prompt: continue
            lyrics = input("  歌詞（留空=純音樂）> ").strip()
            gen_music(prompt, lyrics if lyrics else None)

        elif choice == "2":
            prompt = input("  提示詞（例如：夕陽下的沙灘）> ").strip()
            if not prompt: continue
            ar = input("  比例（1:1/16:9/9:16/4:3，留空=1:1）> ").strip() or "1:1"
            n_str = input("  張數（留空=1）> ").strip()
            n = int(n_str) if n_str.isdigit() else 1
            gen_image(prompt, ar, n)

        elif choice == "3":
            prompt = input("  提示詞（例如：機器人跳舞）> ").strip()
            if not prompt: continue
            dur_str = input("  秒數（6 或 10，留空=6）> ").strip() or "6"
            try: dur = int(dur_str)
            except: dur = 6
            res = input("  解析度（768P/1080P，留空=768P）> ").strip() or "768P"
            gen_video(prompt, dur, res)

        elif choice == "4":
            key = input("  新的 API Key > ").strip()
            if key: save_key(key)

        else:
            print("  無效選項")


if __name__ == "__main__":
    main()
