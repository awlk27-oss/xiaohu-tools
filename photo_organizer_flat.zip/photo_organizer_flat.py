# -*- coding: utf-8 -*-
"""
照片整理（攤平版）v1.0 - 小虎 2026-07-10
- 全部進 E:\照片\ALL\ (沒有任何子資料夾)
- 檔名用拍攝日期 prefix: 20240615_IMG_001.jpg
- 沒 EXIF 的用 mtime 算日期
- 重複檔名自動加 _1, _2 後綴
- 跳過 Pillow EXIF 讀取, 跑超快

依賴: 不需要 (只用 stdlib)
"""

import os
import shutil
import hashlib
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

SOURCE = Path(r'E:\照片')
TARGET = Path(r'E:\照片\ALL')
DUPLICATES = Path(r'E:\重複')  # 完全重複（hash 一樣）才進這

MAX_FILES = 0  # 0 = 不限制, 要分批就改成 5000
SKIP_FILES = 0  # 跳過前 N 個

# 進度檔 (分批用)
PROCESSED_INDEX_FILE = Path(r'E:\photo_flat_processed.txt')
UNDO_LOG_DB = Path(r'E:\photo_flat_log.db')

IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.heic', '.tiff', '.tif', '.webp', '.bmp', '.gif'}
ILLEGAL_CHARS = r'[<>:"/\\|?*\x00-\x1f]'


def safe_filename(name: str) -> str:
    return re.sub(ILLEGAL_CHARS, '_', name).strip(' .')[:200]


def file_hash(path: Path) -> str:
    """用檔案大小 + 修改時間當輕量 fingerprint (比 SHA256 快 100 倍)"""
    try:
        stat = path.stat()
        return f'{stat.st_size}_{int(stat.st_mtime)}'
    except Exception:
        return ''


def get_date_prefix(path: Path) -> str:
    """從 EXIF 讀取 DateTimeOriginal, 失敗時用檔案 mtime"""
    date_str = None
    # 試 EXIF (Pillow optional)
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS
        img = Image.open(path)
        exif = img._getexif()
        if exif:
            for tag_id, value in exif.items():
                tag = TAGS.get(tag_id, tag_id)
                if tag in ('DateTimeOriginal', 'DateTimeDigitized', 'DateTime'):
                    try:
                        d = datetime.strptime(str(value), '%Y:%m:%d %H:%M:%S')
                        return d.strftime('%Y%m%d')
                    except ValueError:
                        continue
    except Exception:
        pass

    # EXIF 失敗: 用 mtime
    try:
        mtime = path.stat().st_mtime
        d = datetime.fromtimestamp(mtime)
        return d.strftime('%Y%m%d')
    except Exception:
        return '00000000'


def init_undo_log():
    import sqlite3
    conn = sqlite3.connect(str(UNDO_LOG_DB))
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS moves (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        copied_at TEXT NOT NULL,
        src_path TEXT NOT NULL,
        dst_path TEXT NOT NULL,
        restored INTEGER DEFAULT 0
    )''')
    conn.commit()
    conn.close()


def log_move(src: Path, dst: Path):
    import sqlite3
    conn = sqlite3.connect(str(UNDO_LOG_DB))
    c = conn.cursor()
    c.execute('INSERT INTO moves (copied_at, src_path, dst_path) VALUES (?, ?, ?)',
              (datetime.now().isoformat(), str(src), str(dst)))
    conn.commit()
    conn.close()


def load_processed() -> set:
    if not PROCESSED_INDEX_FILE.exists():
        return set()
    with open(PROCESSED_INDEX_FILE) as f:
        return set(line.strip() for line in f if line.strip())


def save_processed(new_keys: list):
    if not new_keys:
        return
    with open(PROCESSED_INDEX_FILE, 'a') as f:
        f.write('\n'.join(new_keys) + '\n')


def count_total(source: Path) -> int:
    count = 0
    for p in source.rglob('*'):
        if p.is_file() and p.suffix.lower() in IMAGE_EXT:
            count += 1
    return count


def plan_and_execute():
    if not SOURCE.exists():
        print(f'❌ 來源資料夾不存在: {SOURCE}')
        return

    TARGET.mkdir(parents=True, exist_ok=True)
    DUPLICATES.mkdir(parents=True, exist_ok=True)

    processed = load_processed()
    print(f'📂 掃描中: {SOURCE}')
    if processed:
        print(f'   📋 已處理過 {len(processed)} 個檔 (會跳過)')

    items = []
    skipped_count = 0
    skipped_skip_count = 0
    for path in SOURCE.rglob('*'):
        if not (path.is_file() and path.suffix.lower() in IMAGE_EXT):
            continue
        # SKIP
        if skipped_count < SKIP_FILES:
            skipped_count += 1
            continue
        # 進度檔
        key = file_hash(path)
        if key in processed:
            skipped_skip_count += 1
            continue
        items.append({'path': path, 'key': key})
        if MAX_FILES > 0 and len(items) >= MAX_FILES:
            print(f'   ⚠️  已達 MAX_FILES={MAX_FILES}, 跳過剩餘')
            break

    print(f'   找到 {len(items)} 個新檔 (跳過 {skipped_skip_count} 已處理)')

    if not items:
        print('✅ 沒有新檔要處理')
        return

    print()
    print('🔍 預覽 (前 10 個將被複製的檔):')
    for item in items[:10]:
        p = item['path']
        prefix = get_date_prefix(p)
        new_name = f'{prefix}_{safe_filename(p.name)}'
        print(f'   {p.name}  →  {new_name}')
    if len(items) > 10:
        print(f'   ... 還有 {len(items) - 10} 個')

    print()
    print(f'⚠️  即將把 {len(items)} 個檔案複製到 {TARGET}')
    print(f'   (複製, 不刪除來源)')
    answer = input('確認執行嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('🚫 取消')
        return

    print('\n📦 開始搬檔...')
    init_undo_log()

    copied = 0
    duplicate = 0
    new_keys = []
    name_count = defaultdict(int)

    for i, item in enumerate(items, 1):
        p = item['path']
        prefix = get_date_prefix(p)
        original_name = safe_filename(p.name)
        stem = Path(original_name).stem
        ext = Path(original_name).suffix
        new_name = f'{prefix}_{stem}{ext}'

        # 處理重複檔名
        final_name = new_name
        counter = 1
        while (TARGET / final_name).exists():
            # 檢查 hash, 完全相同就跳過
            if file_hash(p) == file_hash(TARGET / final_name):
                break
            final_name = f'{prefix}_{stem}_{counter}{ext}'
            counter += 1
        else:
            target_path = TARGET / final_name
            shutil.copy2(str(p), str(target_path))
            log_move(p, target_path)
            copied += 1
            new_keys.append(item['key'])
            continue

        # 上面 while break 出來 = 已存在且重複
        duplicate += 1

        if i % 500 == 0:
            print(f'   進度: {i}/{len(items)} ({copied} 新, {duplicate} 重複)')

    save_processed(new_keys)

    print('\n' + '=' * 70)
    print('✅ 完成！')
    print(f'   新複製: {copied} 個檔')
    print(f'   重複跳過: {duplicate} 個檔')
    print(f'   目標資料夾: {TARGET}')
    print(f'   進度檔: {PROCESSED_INDEX_FILE} ({len(load_processed())} 個已記錄)')
    print('=' * 70)


def main():
    print('=' * 70)
    print('🐯 照片整理（攤平版）v1.0')
    print(f'   來源: {SOURCE}')
    print(f'   目標: {TARGET} (一個資料夾，無子分類)')
    print(f'   檔名: 拍攝日期 prefix, 例 20240615_IMG_001.jpg')
    print('=' * 70)

    # 進度報告
    total = count_total(SOURCE)
    processed = len(load_processed())
    remaining = max(0, total - processed)
    if total > 0:
        print('-' * 70)
        print(f'📊 進度報告:')
        print(f'   總共照片:    {total:,} 張')
        print(f'   已整理:      {processed:,} 張 ({processed/total*100:.1f}%)')
        print(f'   剩餘未整理:  {remaining:,} 張 ({remaining/total*100:.1f}%)')
        if MAX_FILES > 0:
            print(f'   本次預計處理: {MAX_FILES:,} 張')
        print('-' * 70)
    print()
    plan_and_execute()


if __name__ == '__main__':
    main()
    print()
    input('按 Enter 關閉視窗...')