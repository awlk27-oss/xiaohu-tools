# -*- coding: utf-8 -*-
"""
照片整理（攤平）復原工具
從 UNDO_LOG_DB 讀搬檔紀錄, 複製 target 回 source
"""

import sqlite3
import shutil
from pathlib import Path
from datetime import datetime

UNDO_LOG_DB = Path(r'E:\photo_flat_log.db')



def main():
    print('=' * 70)
    print('🐯 照片整理（攤平）復原工具')
    print('=' * 70)

    if not UNDO_LOG_DB.exists():
        print(f'❌ 找不到 log: {UNDO_LOG_DB}')
        print('   代表您還沒跑過 photo_organizer_flat')
        return

    conn = sqlite3.connect(str(UNDO_LOG_DB))
    c = conn.cursor()

    # 列出所有記錄
    print('\n📋 所有搬檔紀錄 (總筆數):')
    total = c.execute('SELECT COUNT(*) FROM moves WHERE restored = 0').fetchone()[0]
    print(f'   未復原: {total} 筆')

    if total == 0:
        print('✅ 沒有未復原的記錄')
        conn.close()
        return

    print(f'\n⚠️  此操作會:')
    print('   1. 把 E:\\照片\\ALL\\ 下的檔案 MOVE 回到原來源位置')
    print('   2. E:\\照片\\ALL\\ 下的檔案會被搬走 (不是複製)')
    print('   3. 如果來源已經有新檔, 會跳過 (不覆蓋)')
    print(f'   4. 總共處理 {total} 個檔')
    print()
    answer = input(f'確認復原全部嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('🚫 取消')
        conn.close()
        return

    c.execute('SELECT src_path, dst_path FROM moves WHERE restored = 0')
    rows = c.fetchall()

    restored = 0
    skipped = 0
    for src, dst in rows:
        src_p = Path(src)
        dst_p = Path(dst)
        if not dst_p.exists():
            skipped += 1
            continue
        if src_p.exists():
            skipped += 1
            continue
        src_p.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dst_p), str(src_p))
        restored += 1

    # 標記為已復原
    c.execute('UPDATE moves SET restored = 1')
    conn.commit()
    conn.close()

    print(f'\n✅ 復原完成: {restored} 個檔被搬回原來源, {skipped} 個跳過')
    print(f'💡 跳過的是因為來源已經有新檔了, 沒動 E:\\照片\\ALL\\ (那些被搬走的已經搬回來源)')


if __name__ == '__main__':
    main()
    print()
    input('按 Enter 關閉視窗...')