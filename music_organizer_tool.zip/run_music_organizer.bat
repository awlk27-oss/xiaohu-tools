@echo off
rem Switch to UTF-8 for Chinese output
chcp 65001 >nul 2>&1
cd /d "%~dp0"
echo ============================================================
echo   Music Organizer Tool v1.0 (xiaohu 2026-07-10)
echo ============================================================
echo.

rem Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

rem Check mutagen
python -c "import mutagen" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installing mutagen...
    pip install mutagen
    if errorlevel 1 (
        echo [ERROR] Install failed. Try: pip install mutagen
        pause
        exit /b 1
    )
)

echo.
python music_organizer.py

echo.
pause