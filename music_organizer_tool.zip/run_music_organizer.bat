@echo off
chcp 65001 > nul
cd /d %~dp0
echo ============================================================
echo   音樂整理工具 v1.0 (小虎 2026-07-10)
echo ============================================================
echo.

REM 檢查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 找不到 Python，請先裝 Python 3.10+
    echo    下載: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM 檢查 mutagen
python -c "import mutagen" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  沒裝 mutagen，正在自動安裝...
    pip install mutagen
    if errorlevel 1 (
        echo ❌ 安裝失敗，請手動跑: pip install mutagen
        pause
        exit /b 1
    )
)

echo.
python music_organizer.py

echo.
pause
