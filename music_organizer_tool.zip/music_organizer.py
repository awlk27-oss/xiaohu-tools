# -*- coding: utf-8 -*-
"""
音樂整理工具 - 小虎 v1.0 (2026-07-10)

功能：
  把 D:\音樂 整理成 D:\音樂_整理\年\藝人\
  + D:\音樂_整理\未知\ (無 ID3)
  + D:\重複\ (重複檔)
  + 播放清單 (m3u)

分類規則：
  第一層：年 (ID3 year 或檔案 mtime)
  第二層：藝人 (ID3 artist)

兩階段執行：
  階段 1（預覽）：只列出計畫，不實際搬檔
  階段 2（執行）：按計畫搬檔 + 建 m3u

依賴：
  pip install mutagen
"""

import os
import sys
import shutil
import hashlib
import re
from pathlib import Path
from collections import defaultdict
from datetime import datetime

# 嘗試 import mutagen (讀 ID3 tag)
try:
    from mutagen.mp3 import MP3
    from mutagen.flac import FLAC
    from mutagen.mp4 import MP4
    from mutagen.id3 import ID3NoHeaderError
    HAS_MUTAGEN = True
except ImportError:
    HAS_MUTAGEN = False
    print('⚠️  沒裝 mutagen，ID3 tag 抓不到，請先跑: pip install mutagen')

# ========== 常數 ==========
SOURCE = Path(r'D:\音樂')
TARGET = Path(r'D:\音樂_整理')
DUPLICATES = Path(r'D:\重複')
PLAYLISTS = TARGET / '播放清單'
UNKNOWN = TARGET / '未知'

AUDIO_EXT = {'.mp3', '.flac', '.m4a', '.wav', '.ogg', '.wma', '.aac'}

# 非法檔名字元（Windows）
ILLEGAL_CHARS = r'[<>:"/\\|?*\x00-\x1f]'


def safe_filename(name: str) -> str:
    """移除非法字元，trim 空白"""
    name = re.sub(ILLEGAL_CHARS, '_', name)
    name = name.strip(' .')
    return name[:200]  # Windows 路徑上限


def file_hash(path: Path, chunk=65536) -> str:
    """算檔案 SHA256 用於比對"""
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            while chunk := f.read(chunk := 65536):
                h.update(chunk)
    except Exception as e:
        return f'ERR_{e}'
    return h.hexdigest()


def get_id3_tags(path: Path) -> dict:
    """用 mutagen 抓 ID3 tag"""
    if not HAS_MUTAGEN:
        return {}
    try:
        ext = path.suffix.lower()
        if ext == '.mp3':
            audio = MP3(path, ID3=MP3.ID3)
        elif ext == '.flac':
            audio = FLAC(path)
        elif ext in ('.m4a', '.mp4'):
            audio = MP4(path)
        else:
            return {}

        artist = ''
        title = ''
        year = ''

        if hasattr(audio, 'tags') and audio.tags:
            # ID3 (MP3)
            if 'TPE1' in audio.tags:
                artist = str(audio.tags['TPE1'])
            elif 'TPE2' in audio.tags:
                artist = str(audio.tags['TPE2'])
            elif '\xa9ART' in audio.tags:
                artist = str(audio.tags['\xa9ART'][0])

            if 'TIT2' in audio.tags:
                title = str(audio.tags['TIT2'])
            elif '\xa9nam' in audio.tags:
                title = str(audio.tags['\xa9nam'][0])

            # 年份
            for tag in ('TDRC', 'TYER', '\xa9day', 'date'):
                if tag in audio.tags:
                    val = str(audio.tags[tag])
                    m = re.search(r'(\d{4})', val)
                    if m:
                        year = m.group(1)
                        break
        return {'artist': artist.strip(), 'title': title.strip(), 'year': year}
    except Exception:
        return {}


def get_year_from_mtime(path: Path) -> str:
    """沒 ID3 時，用檔案 mtime 取年"""
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).strftime('%Y')
    except Exception:
        return '未知年'


def scan_music(source: Path) -> list:
    """掃來源資料夾，回傳所有音樂檔 + 標籤"""
    items = []
    if not source.exists():
        print(f'❌ 來源資料夾不存在: {source}')
        return items

    print(f'🔍 掃描中: {source}')
    for path in source.rglob('*'):
        if path.is_file() and path.suffix.lower() in AUDIO_EXT:
            tags = get_id3_tags(path)
            items.append({
                'path': path,
                'size': path.stat().st_size,
                'artist': tags.get('artist', ''),
                'title': tags.get('title', ''),
                'year': tags.get('year', '') or get_year_from_mtime(path),
            })
    print(f'   找到 {len(items)} 個音樂檔')
    return items


def plan_organization(items: list) -> dict:
    """規劃整理計畫（不實際搬）"""
    plan = {
        'to_classify': [],   # 進 年/藝人/
        'to_unknown': [],    # 進 未知/
        'to_duplicate': [],  # 進 重複/
        'duplicates': 0,
        'years': defaultdict(set),
        'artists': set(),
        'by_year_artist': defaultdict(list),  # (year, artist) -> [items]
    }

    # 先算 hash 找重複
    hash_map = defaultdict(list)
    for item in items:
        h = file_hash(item['path'])
        item['hash'] = h
        hash_map[h].append(item)

    seen_hash = set()
    for item in items:
        h = item['hash']
        if h in seen_hash:
            # 已處理過這個 hash，跳過
            continue
        seen_hash.add(h)

        same_hash = hash_map[h]
        if len(same_hash) > 1:
            # 第 1 份照規則進分類
            first = same_hash[0]
            plan = _dispatch(first, plan)
            # 剩下的進重複
            for dup in same_hash[1:]:
                plan['to_duplicate'].append(dup)
                plan['duplicates'] += 1
        else:
            plan = _dispatch(item, plan)

    return plan


def _dispatch(item: dict, plan: dict) -> dict:
    """判斷 item 該去哪"""
    if not item['artist'] or not item['title']:
        # 沒 tag → 未知
        plan['to_unknown'].append(item)
        return plan

    plan['to_classify'].append(item)
    plan['years'][item['year']].add(item['artist'])
    plan['artists'].add(item['artist'])
    plan['by_year_artist'][(item['year'], item['artist'])].append(item)
    return plan


def print_plan(plan: dict, items: list) -> None:
    """預覽模式：印出計畫"""
    print('\n' + '=' * 70)
    print('📋 整理計畫預覽')
    print('=' * 70)
    print(f'總共掃到:    {len(items)} 個音樂檔')
    print(f'  分類:       {len(plan["to_classify"])} 個 →  年\\藝人\\')
    print(f'  無 ID3:     {len(plan["to_unknown"])} 個 →  未知\\')
    print(f'  重複:       {plan["duplicates"]} 個 →  D:\\重複\\')
    print(f'  年代數:     {len(plan["years"])} 個 ({", ".join(sorted(plan["years"].keys()))})')
    print(f'  藝人數:     {len(plan["artists"])} 個')

    # 顯示前 10 個藝人
    artists = sorted(plan['artists'])[:10]
    print(f'\n🎤 藝人範例: {", ".join(artists)}' + ('...' if len(plan["artists"]) > 10 else ''))

    # 顯示前 5 個年/藝人組合
    print(f'\n📂 部分年/藝人資料夾範例:')
    for (year, artist), items_in in sorted(plan['by_year_artist'].items())[:5]:
        print(f'   {year}\\{artist}\\  ({len(items_in)} 首)')

    print('\n' + '=' * 70)


def execute_plan(plan: dict) -> None:
    """執行模式：實際搬檔 + 建 m3u"""
    TARGET.mkdir(parents=True, exist_ok=True)
    UNKNOWN.mkdir(parents=True, exist_ok=True)
    DUPLICATES.mkdir(parents=True, exist_ok=True)
    PLAYLISTS.mkdir(parents=True, exist_ok=True)

    # 1. 分類進 年\藝人\
    print('\n📂 分類中...')
    for item in plan['to_classify']:
        year = safe_filename(item['year'])
        artist = safe_filename(item['artist'])
        title = safe_filename(item['title'])
        ext = item['path'].suffix
        target_dir = TARGET / year / artist
        target_dir.mkdir(parents=True, exist_ok=True)

        new_name = f'{artist} - {title}{ext}'
        target_path = target_dir / new_name

        # 同檔名加 _1 _2
        counter = 1
        while target_path.exists():
            new_name = f'{artist} - {title}_{counter}{ext}'
            target_path = target_dir / new_name
            counter += 1

        shutil.copy2(item['path'], target_path)

    # 2. 無 ID3 → 未知\
    print('📦 未知目錄...')
    for item in plan['to_unknown']:
        target_path = UNKNOWN / item['path'].name
        # 處理重複
        counter = 1
        original = target_path
        while target_path.exists():
            target_path = original.with_name(f'{original.stem}_{counter}{original.suffix}')
            counter += 1
        shutil.copy2(item['path'], target_path)

    # 3. 重複 → D:\重複\
    print('🔁 重複目錄...')
    for item in plan['to_duplicate']:
        # 用 來源子路徑當子資料夾名（避免混在一起）
        try:
            rel = item['path'].relative_to(SOURCE)
        except ValueError:
            rel = Path(item['path'].name)
        sub_dir = DUPLICATES / rel.parent
        sub_dir.mkdir(parents=True, exist_ok=True)
        target_path = sub_dir / item['path'].name
        counter = 1
        original = target_path
        while target_path.exists():
            target_path = original.with_name(f'{original.stem}_{counter}{original.suffix}')
            counter += 1
        shutil.copy2(item['path'], target_path)

    # 4. 建 m3u
    print('🎵 建播放清單...')
    _build_year_playlists(plan)
    _build_artist_playlists(plan)
    print('✅ 全部完成！')


def _build_year_playlists(plan: dict):
    """每個年一份 .m3u"""
    by_year = defaultdict(list)
    for item in plan['to_classify']:
        by_year[item['year']].append(item)

    for year, items_in in sorted(by_year.items()):
        path = PLAYLISTS / f'{safe_filename(year)}.m3u'
        with open(path, 'w', encoding='utf-8') as f:
            f.write('#EXTM3U\n')
            for item in sorted(items_in, key=lambda x: (x['artist'], x['title'])):
                # m3u 用相對路徑或絕對路徑
                actual = TARGET / safe_filename(item['year']) / safe_filename(item['artist']) / f'{safe_filename(item["artist"])} - {safe_filename(item["title"])}{item["path"].suffix}'
                f.write(f'{actual}\n')
        print(f'   ✓ {path.name}  ({len(items_in)} 首)')


def _build_artist_playlists(plan: dict):
    """每個藝人一份 .m3u"""
    by_artist = defaultdict(list)
    for item in plan['to_classify']:
        by_artist[item['artist']].append(item)

    for artist, items_in in sorted(by_artist.items()):
        safe = safe_filename(artist)
        path = PLAYLISTS / f'{safe}.m3u'
        with open(path, 'w', encoding='utf-8') as f:
            f.write('#EXTM3U\n')
            for item in sorted(items_in, key=lambda x: x['year']):
                actual = TARGET / safe_filename(item['year']) / safe / f'{safe} - {safe_filename(item["title"])}{item["path"].suffix}'
                f.write(f'{actual}\n')
        print(f'   ✓ {path.name}  ({len(items_in)} 首)')


def main():
    print('=' * 70)
    print('🐯 音樂整理工具 v1.0')
    print('=' * 70)

    if not HAS_MUTAGEN:
        print('\n❌ 缺 mutagen，請先裝:')
        print('   pip install mutagen')
        return

    if not SOURCE.exists():
        print(f'\n❌ 來源資料夾不存在: {SOURCE}')
        print('   請確認 D:\\音樂 是否有音樂檔')
        return

    # 掃描
    items = scan_music(SOURCE)
    if not items:
        print('\n❌ 沒掃到任何音樂檔，請確認來源資料夾')
        return

    # 規劃
    plan = plan_organization(items)

    # 預覽
    print_plan(plan, items)

    # 詢問
    print('\n⚠️  即將開始實際搬檔到 D:\\音樂_整理\\')
    print('   來源 D:\\音樂 不會被刪除（只 copy 不 move）')
    answer = input('\n確認執行嗎？(y/N): ').strip().lower()
    if answer != 'y':
        print('\n🚫 已取消，沒動到任何檔案')
        return

    # 執行
    execute_plan(plan)


if __name__ == '__main__':
    main()
    print()
    print('=' * 70)
    print('  跑完了！按 Enter 關閉視窗...')
    print('=' * 70)
    input()
